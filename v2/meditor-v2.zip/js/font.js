var fontFamilyMenu = null;
var fontSizeMenu = null;
function AddFontBtn() {
    // Yeni family-container HTML yapısını oluşturuyoruz
    const fontContainer = document.createElement('div');
    fontContainer.id = 'font-container';
    fontContainer.innerHTML = `
        <div class="font-family">
            <button type="button" id="fontFamilyBtn">
                <span class="me-buton" onclick="openFontFamilyMenu()" title="Yazı Tipi Stili" style="margin-right:5px">
                    <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M186-80q-54 0-80-22t-26-66q0-58 49-74t116-16h21v-56q0-34-1-55.5t-6-35.5q-5-14-11.5-19.5T230-430q-9 0-16.5 3t-12.5 8q-4 5-5 10.5t1 11.5q6 11 14 21.5t8 24.5q0 25-17.5 42.5T159-291q-25 0-42.5-17.5T99-351q0-27 12-44t32.5-27q20.5-10 47.5-14t58-4q85 0 118 30.5T400-302v147q0 19 4.5 28t15.5 9q12 0 19.5-18t9.5-56h11q-3 62-23.5 87T368-80q-43 0-67.5-13.5T269-134q-10 29-29.5 41.5T186-80Zm373 0q-20 0-32.5-16.5T522-132l102-269q7-17 22-28t34-11q19 0 34 11t22 28l102 269q8 19-4.5 35.5T801-80q-12 0-22-7t-15-19l-20-58H616l-20 58q-4 11-14 18.5T559-80Zm-324-29q13 0 22-20.5t9-49.5v-67q-26 0-38 15.5T216-180v11q0 36 4 48t15 12Zm407-125h77l-39-114-38 114Zm-37-285q-48 0-76.5-33.5T500-643q0-104 66-170.5T735-880q42 0 68 9.5t26 24.5q0 6-2 12t-7 11q-5 7-12.5 10t-15.5 1q-14-4-32-7t-33-3q-71 0-114 48t-43 127q0 22 8 46t36 24q11 0 21.5-5t18.5-14q17-18 31.5-60T712-758q2-13 10.5-18.5T746-782q18 0 27.5 9.5T779-749q-12 43-17.5 75t-5.5 58q0 20 5.5 29t16.5 9q11 0 21.5-8t29.5-30q2-3 15-7 8 0 12 6t4 17q0 28-32 54t-67 26q-26 0-44.5-14T691-574q-15 26-37 40.5T605-519Zm-485-1v-220q0-58 41-99t99-41q58 0 99 41t41 99v220h-80v-80H200v80h-80Zm80-160h120v-60q0-25-17.5-42.5T260-800q-25 0-42.5 17.5T200-740v60Z"/></svg>
                </span>
                <span id="font-family-name" onclick="openFontFamilyMenu()" title="Yazı Tipi Stili" style="width:85px;border: 1px solid gray;white-space: nowrap;overflow: hidden; text-overflow: ellipsis;">Arial</span>
                <span class="me-buton" onclick="applyFontFamily('')" title="Yazı Tipi Stilini Kaldır" style="border: 1px solid black; margin-left:5px;">
                    <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#1f1f1f"><path d="m131-252 127-338L56-792l56-56 736 736-56 56-286-286 34 90h-76l-39-112H247l-40 112h-76Zm178-287-39 111h131l-10-29-82-82Zm436 210q8-10 12-22t4-25q-14-8-33.5-12.5T689-393h-8l-45-45q10-2 20-3.5t21-1.5q23 0 45 4t38 11v-12q0-29-20.5-47T685-505q-23 0-42 9.5T610-468l-43-39q23-27 52.5-40t66.5-13q69 0 103 32.5t34 97.5v179l-78-78Z"/></svg>
                </span>
            </button>
            <div id="font-family-menu" style="display:none">
                <ul>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Arial', sans-serif;">Arial</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Roboto', sans-serif;">Roboto</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Verdana', sans-serif;">Verdana</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Tahoma', sans-serif;">Tahoma</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Comic Sans MS', cursive;">Comic Sans MS</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Dancing Script', cursive;">Dancing Script</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Fredericka the Great', cursive;">Fredericka Great</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Impact', sans-serif;">Impact</li>
    				<li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Pacifico', cursive;">Pacifico</li>
    				<li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Lobster', cursive;">Lobster</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Oswald', sans-serif;">Oswald</li>
    				<li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Ubuntu', sans-serif;">Ubuntu</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Courier New', monospace;">Courier New</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Georgia', serif;">Georgia</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Times New Roman', serif;">Times New Roman</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Droid Sans', sans-serif;">Droid Sans</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Playfair Display', serif;">Playfair Display</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Montserrat', sans-serif;">Montserrat</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Raleway', sans-serif;">Raleway</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Slabo 27px', serif;">Slabo 27px</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Bitter', serif;">Bitter</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Cinzel', serif;">Cinzel</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Quicksand', sans-serif;">Quicksand</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Anton', sans-serif;">Anton</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Zilla Slab', serif;">Zilla Slab</li>
                    <li onclick="applyFontFamily(this.style.fontFamily)" style="font-family: 'Abril Fatface', serif;">Abril Fatface</li>
                </ul>
            </div>
        </div>
        <div class="font-size">
            <button type="button" id="fontSizeBtn">
                <span class="me-buton" onclick="openFontSizeMenu();" title="Yazı Tipi Boyutu" style="margin-right: 5px">
                    <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-160v-520H80v-120h520v120H400v520H280Zm360 0v-320H520v-120h360v120H760v320H640Z"/></svg>
                </span>
                <span id="font-size-minus" type="button" title="Yazı Tipi Boyutunu Küçült" style="width:20px; border: 1px solid black; margin-right:1px; border-radius: 3px;" onclick="applyFontSize(parseInt(this.nextElementSibling.value)-2+'pt');">-</span>
                <input id="font-size-manuel" type="text" style="width:55px;text-align:center;" placeholder="12pt" onclick="this.value='';" onmousedown="secimiKoru();" onblur="this.value=currentSize+'pt'" onchange="updateFontSize(this.value.replace(/[^0-9]/g, ''));">
                <span id="font-size-plus" type="button" title="Yazı Tipi Boyutunu Büyüt" style="width:20px; border: 1px solid black; margin-left:1px; border-radius: 3px;" onclick="applyFontSize(parseInt(this.previousElementSibling.value)+2+'pt');">+</span>

                <span class="me-buton" onclick="applyFontSize('')" title="Yazı Tipi Boyutunu Kaldır" style="border: 1px solid black; margin-left:5px;">
                    <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#1f1f1f"><path d="m528-546-93-93-121-121h486v120H568l-40 94ZM792-56 460-388l-80 188H249l119-280L56-792l56-56 736 736-56 56Z"/></svg>
                </span>
            </button>
            <div id="font-size-menu" style="display:none">
                <ul>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:12pt;">12pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:18pt;">18pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:21pt;">21pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:27pt;">27pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:33pt;">33pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:39pt;">39pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:45pt;">45pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:50pt;">50pt</li>
    				<li onclick="applyFontSize(this.style.fontSize)" style="font-size:60pt;">60pt</li>
                </ul>
            </div>
        </div>
        
    `;

    if (toolbar) {toolbar.appendChild(fontContainer);}
	fontFamilyMenu = document.getElementById('font-family-menu');
	fontSizeMenu = document.getElementById('font-size-menu');

}

document.querySelectorAll('li').forEach(function(li) {
    li.addEventListener('mouseover', function(event) {
		var line = event.target;
        li.timeoutId = setTimeout(function(event) {
        }, 5000);
    });

    li.addEventListener('mouseleave', function() {
        clearTimeout(li.timeoutId);
        document.getElementById('font-family-menu').style.opacity = 1;
    });
});

editor.addEventListener('click', function(event){
    const fname = document.getElementById('font-family-name');
    const computedStyle = window.getComputedStyle(event.target);
    const fontFamilyName = computedStyle.fontFamily || '...';
    fname.style.fontFamily = fontFamilyName;
    fname.innerText = fontFamilyName.replace('"','');
    fname.title = fontFamilyName;
});

function openFontFamilyMenu() {
    const menu = document.getElementById('font-family-menu');
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
}

// Dökümanın herhangi bir yerine tıklandığında menüyü kapat
document.addEventListener('click', function(event) {
    const menu = document.getElementById('font-family-menu');
    if (!event.target.closest('#fontFamilyBtn') && 
        !event.target.closest('#font-family-menu')) {
        menu.style.display = 'none';
    }
});

function applyFontFamily(family) {
    const selection = window.getSelection();
    const range = selection.getRangeAt(0);
    const commonAncestor = range.commonAncestorContainer;
    if (editor.contains(commonAncestor)) {   
        const selectedText = selection.toString(); // Seçilen metni al
        const fontFamilyNameElement = document.getElementById('font-family-name');
        fontFamilyNameElement.innerText = family.replace('"', '');
        fontFamilyNameElement.title = family;
        fontFamilyNameElement.style.fontFamily = family;
        fontFamilyMenu.style.display = 'none';
        if (selectedText) {
            const selectedNode = range.startContainer;
            const parentElement = selectedNode.parentElement;
            if (range.startOffset > 0 || (selectedNode.previousSibling && selectedNode.previousSibling.nodeType === Node.TEXT_NODE)) {
                const newSpan = document.createElement('span');
                newSpan.style.fontFamily = family;
                newSpan.innerText = selectedText;
                range.deleteContents();
                range.insertNode(newSpan);
                moveCursorToEnd(newSpan);
            } else {
                parentElement.style.fontFamily = family;
                moveCursorToEnd(parentElement);
            }
        } else {
            let selectedElement = commonAncestor;
            if (selectedElement.nodeType === Node.TEXT_NODE) {
                selectedElement = selectedElement.parentElement;
            }
            selectedElement.style.fontFamily = family;
            moveCursorToEnd(selectedElement);            
        }
    }
}




let currentSize = 12;

function secimiKoru() {
    const selection = window.getSelection(); // Kullanıcının yaptığı metin seçimini al
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0); // Seçilen aralığı al
        const selectedText = selection.toString(); // Seçilen metni al ve boşlukları temizle
        const words = selectedText.trim().split(/\s+/); // Boşluklara göre ayır

        if (words.length === 1) { // Yalnızca bir kelime seçiliyse
            const parentNode = range.commonAncestorContainer;

            // Eğer zaten bir span içindeyse kontrol et
            if (parentNode.nodeType === Node.TEXT_NODE && parentNode.parentElement.tagName === 'SPAN') {
                parentNode.parentElement.classList.add('secilenkelime');
            } else {
                // Yeni bir span ekle
                const span = document.createElement('span');
                span.classList.add('secilenkelime');
                span.textContent = selectedText; // Seçilen kelimenin sonuna boşluk ekle
                range.deleteContents(); // Seçili metni sil
                range.insertNode(span); // Yeni span'i ekle
            }
        }
    }
    editor.addEventListener('click', function removeHighlight(event) {
        const sk = editor.querySelector('.secilenkelime');
        if(sk){
            sk.classList.remove('secilenkelime');
        }
    });
}

editor.addEventListener('click', function(event){
    event.target.parentElement.classList.remove('secilenkelime');

	const fsize = document.getElementById('font-size-manuel');
    const computedStyle = window.getComputedStyle(event.target);
	const fontSizePx = parseFloat(computedStyle.fontSize);
	const fontSizePt = Math.floor(fontSizePx / 1.3333);
    fsize.value = fontSizePt + 'pt';
    currentSize = fontSizePt;
});

function updateFontSize(size) {
    const sk = editor.querySelector('.secilenkelime');
    sk.style.fontSize = `${size}pt`;
    sk.classList.remove('secilenkelime');
    moveCursorToEnd(sk);
    currentSize = parseInt(size);
    document.getElementById('font-size-manuel').value = size + 'pt';
}

function changeFontSize(increment, manualSize = null) {
    if (manualSize) {currentSize = manualSize;} else {currentSize += increment;}
    if (currentSize < 6) currentSize = 6;
    if (currentSize > 200) currentSize = 200;
    document.getElementById('font-size-manuel').value = currentSize + 'pt';
    applyFontSize(currentSize + 'pt');
}
editor.addEventListener('wheel', function (e) {
    if (!e.ctrlKey) return;
    if (e.deltaY < 0) {changeFontSize(2);} else if (e.deltaY > 0) {changeFontSize(-2);}
	e.preventDefault(); 
});

function openFontSizeMenu() {
    const menu = document.getElementById('font-size-menu');
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
}

// Dökümanın herhangi bir yerine tıklandığında menüyü kapat
document.addEventListener('click', function(event) {
    const menu = document.getElementById('font-size-menu');
    if (!event.target.closest('#fontSizeBtn') && 
        !event.target.closest('#font-size-menu')) {
        menu.style.display = 'none';
    }
});

function applyFontSize(size) {
    const selection = window.getSelection();
    const range = selection.getRangeAt(0);
    const commonAncestor = range.commonAncestorContainer;

    // Seçimin sadece "editor" içinde olmasını kontrol et
    if (editor.contains(commonAncestor)) {
        const selectedText = selection.toString(); // Seçilen metni al
        const fontSizeElement = document.getElementById('font-size-manuel');
        fontSizeElement.value = size;  // Font boyutunu manuel input'a yerleştir
        fontSizeMenu.style.display = 'none';

        const currentSize = parseInt(fontSizeElement.value.replace('pt', ''));

        if (selectedText) {
            // Seçilen metni span içine alarak font boyutunu değiştir
            const selectedNode = range.startContainer;
            const parentElement = selectedNode.parentElement;

            // Seçilen kelimeden önce başka kelimeler varsa
            if (range.startOffset > 0 || (selectedNode.previousSibling && selectedNode.previousSibling.nodeType === Node.TEXT_NODE)) {
                // Seçilen metni bir span içine al
                const newSpan = document.createElement('span');
                newSpan.style.fontSize = `${size}`;
                newSpan.innerText = selectedText;
                range.deleteContents();
                range.insertNode(newSpan);
                moveCursorToEnd(newSpan);
            } else {
                // Seçilen metin varsa, sadece parent element'in font boyutunu değiştir
                parentElement.style.fontSize = `${size}`;
                moveCursorToEnd(parentElement);
            }
        } else {
            // Eğer metin seçilmemişse, içerik elemanının font boyutunu değiştir
            let selectedElement = commonAncestor;
            if (selectedElement.nodeType === Node.TEXT_NODE) {
                selectedElement = selectedElement.parentElement;
            }
            selectedElement.style.fontSize = `${size}`;
            moveCursorToEnd(selectedElement);            
        }
    }
}