function AddImageBtn() {
    const imageContainer = document.createElement('div');
    imageContainer.id = 'medya-container';
    imageContainer.innerHTML = `
        <button type="button" id="resimBtn" title="Resim Ekle" onclick="openModal('resimModal')">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm40-80h480L570-480 450-320l-90-120-120 160Zm-40 80v-560 560Z"/></svg>
            </span>
        </button>        
		<button type="button" id="videoBtn" title="Video Ekle" onclick="openModal('videoModal')">
			<span class="me-buton">
			    <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="m480-420 240-160-240-160v320Zm28 220h224q-7 26-24 42t-44 20L228-85q-33 5-59.5-15.5T138-154L85-591q-4-33 16-59t53-30l46-6v80l-36 5 54 437 290-36Zm-148-80q-33 0-56.5-23.5T280-360v-440q0-33 23.5-56.5T360-880h440q33 0 56.5 23.5T880-800v440q0 33-23.5 56.5T800-280H360Zm0-80h440v-440H360v440Zm220-220ZM218-164Z"/></svg>
			</span>
        </button>
		<div id="resimModal" class="me-modal" style="display:none">
			<div class="me-modal-content">
				<div class="me-modal-header">
					<h5 class="me-modal-title">Resim Ekle</h5>
				</div>
				<div class="me-modal-body">
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 20px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Resim Yükleme Bölümü </span>
						<br>
						<input type="url" id="imageUrl" placeholder="Resim URL'sini girin" style="width: 40%;"> veya 
						<input type="file" id="imageFile" accept="image/*" onchange="previewImage(event)" style="width: 40%;padding:0">
					</div>
					<div id="imagePreview" style="margin-top: 15px; display: none; text-align: center">
						<h4>Önizleme</h4>
						<img id="previewImg" src="" alt="Önizleme Resmi" style="max-height: 250px; max-width: 400px;">
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 20px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Resim Detayları </span>
						<br>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M320-80 160-240l160-160 57 56-64 64h334l-63-64 56-56 160 160L640-80l-57-56 64-64H313l63 64-56 56ZM200-480v-400h80v400h-80Zm240 0v-400h80v400h-80Zm240 0v-400h80v400h-80Z"/></svg>
						<select id="imageAlign" style="width:80px" title="Hiza">
							<option value="left">Sol</option>
							<option value="center" selected>Orta</option>
							<option value="right">Sağ</option>
						</select>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z"/></svg><input type="number" id="imageWidth" value="250" min="1" max="1024" placeholder="pc" style="width:70px" title="Genişlik">
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M480-144 336-288l51-51 57 57v-396l-57 57-51-51 144-144 144 144-51 51-57-57v396l57-57 51 51-144 144Z"/></svg><input type="number" id="imageHeight" value="" min="1" max="2048" placeholder="Auto" style="width:70px" title="Yükseklik">
						<br>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M444-288h72v-240h-72v240Zm35.79-312q15.21 0 25.71-10.29t10.5-25.5q0-15.21-10.29-25.71t-25.5-10.5q-15.21 0-25.71 10.29t-10.5 25.5q0 15.21 10.29 25.71t25.5 10.5Zm.49 504Q401-96 331-126t-122.5-82.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.96-834q69.96-30 149.5-30t149.04 30q69.5 30 122 82.5T834-629.28q30 69.73 30 149Q864-401 834-331t-82.5 122.5Q699-156 629.28-126q-69.73 30-149 30Zm-.28-72q130 0 221-91t91-221q0-130-91-221t-221-91q-130 0-221 91t-91 221q0 130 91 221t221 91Zm0-312Z"/></svg><input type="text" id="imageTitle" placeholder="Alt Bilgisi" style="width: 76%" title="Alt Bilgi">
					</div>
				</div>
				<div class="me-modal-footer">
					<button type="button" onclick="insertImage()">Resim Ekle</button>
					<button type="button" onclick="resetImageForm()">İptal Et</button>
				</div>
			</div>
		</div>
		<div id="videoModal" class="me-modal" style="display:none">
			<div class="me-modal-content">
				<div class="me-modal-header">
					<h5 class="me-modal-title">Video URL Ekle</h5>
				</div>
				<div class="me-modal-body">
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Video Yükleme Bölümü </span>
						<br>
						<input type="url" id="videoUrl" placeholder="Video URL'sini girin" style="width: 80%;">
					</div>
					<div id="videoPreview" style="margin-top: 15px; display: none; text-align: center">
						<h4>Önizleme</h4>
						<iframe id="previewIframe" src="" style="width: 100%; max-width: 560px; height: 315px; border: none;" allowfullscreen></iframe>
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Video Detayları </span>
						<br>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M320-80 160-240l160-160 57 56-64 64h334l-63-64 56-56 160 160L640-80l-57-56 64-64H313l63 64-56 56ZM200-480v-400h80v400h-80Zm240 0v-400h80v400h-80Zm240 0v-400h80v400h-80Z"/></svg>
						<select id="videoAlign" style="width:80px" title="Hiza">
							<option value="left">Sol</option>
							<option value="center" selected>Orta</option>
							<option value="right">Sağ</option>
						</select>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z"/></svg><input type="number" id="videoWidth" value="560" min="1" max="1024" placeholder="Genişlik" style="width:70px" title="Genişlik">
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M480-144 336-288l51-51 57 57v-396l-57 57-51-51 144-144 144 144-51 51-57-57v396l57-57 51 51-144 144Z"/></svg><input type="number" id="videoHeight" value="315" min="1" max="2048" placeholder="Yükseklik" style="width:70px" title="Yükseklik">
						<br>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M444-288h72v-240h-72v240Zm35.79-312q15.21 0 25.71-10.29t10.5-25.5q0-15.21-10.29-25.71t-25.5-10.5q-15.21 0-25.71 10.29t-10.5 25.5q0 15.21 10.29 25.71t25.5 10.5Zm.49 504Q401-96 331-126t-122.5-82.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.96-834q69.96-30 149.5-30t149.04 30q69.5 30 122 82.5T834-629.28q30 69.73 30 149Q864-401 834-331t-82.5 122.5Q699-156 629.28-126q-69.73 30-149 30Zm-.28-72q130 0 221-91t91-221q0-130-91-221t-221-91q-130 0-221 91t-91 221q0 130 91 221t221 91Zm0-312Z"/></svg><input type="text" id="videoTitle" placeholder="Video Başlığı" style="width: 76%" title="Başlık">

					</div>
				</div>
				<div class="me-modal-footer">
					<button type="button" onclick="previewVideo()">Önizleme Yap</button>
					<button type="button" onclick="insertVideo()">Video Ekle</button>
					<button type="button" onclick="resetVideoForm()">İptal Et</button>
				</div>
			</div>
		</div>
		<div id="resimDuzenle" class="sagtusmenu" style="display:none">
			<div id="dragHandle" class="drag-handle" style="width:100%;text-align:center">
				<span style="font-weight:bold">Resim Ayarı Menüsü</span> 
			</div>
			<label for="editWidth">Genişlik: </label><input type="number" id="editWidth" placeholder="Auto" value="30" title="Genişlik">
			<select id="editWidthType" title="widthtype" style="width:50px" onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
				<option value="px"selected>Px</option>
				<option value="%" >%</option>
			</select>
			<div style="width:100%"></div>
			<label for="editHeight">Yükseklik (px):</label><input type="number" id="editHeight" placeholder="Auto" value="30" title="Yükseklik">
			<select id="editHeightType" title="widthtype" style="width:50px" onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
				<option value="px"selected>Px</option>
				<option value="%" >%</option>
			</select>
			<div style="width:100%"></div>
			<label for="editAlign">Hizalama:</label>
			<select id="editAlign" title="Hiza" style="width:80px">
				<option value="left">Sol</option>
				<option value="center">Ortala</option>
				<option value="right">Sağ</option>
			</select>
			<div style="width:100%"></div>
			<label for="editTitle">Alt Bilgisi:</label>
			<input type="text" id="editTitle" placeholder="Title bilgisi girin" style="width:100px" title="Title Bilgi">
			<div class="me-modal-footer">
				<button type="button" onclick="updateImage()">Güncelle</button>
				<button type="button" onclick="deleteImage()">Kaldır</button>
				<button type="button" onclick="this.parentNode.parentNode.style.display='none'">Kapat</button>
			</div>
		</div>
		<div id="videoDuzenle" class="sagtusmenu" style="display:none">
			<div id="dragHandle" class="drag-handle" style="width:100%;text-align:center">
				<span style="font-weight:bold">Video Ayarı Menüsü</span> 
			</div>
			<label for="editVideoWidth">Genişlik: </label><input type="number" id="editVideoWidth" placeholder="Auto" value="560" title="Genişlik">
			<select id="editVideoWidthType" title="widthtype" style="width:50px" onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
				<option value="px"selected>Px</option>
				<option value="%" >%</option>
			</select>
			<div style="width:100%"></div>
			<label for="editVideoHeight">Yükseklik: </label><input type="number" id="editVideoHeight" placeholder="Auto" value="315" title="Yükseklik">
			<select id="editVideoHeightType" title="heighttype" style="width:50px"onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
				<option value="px"selected>Px</option>
				<option value="%" >%</option>
			</select>
			<div style="width:100%"></div>
			<label for="editVideoAlign">Hizalama:</label>
			<select id="editVideoAlign" title="Hiza" style="width:80px">
				<option value="left">Sol</option>
				<option value="center" selected>Ortala</option>
				<option value="right">Sağ</option>
			</select>
			<div style="width:100%"></div>
			<label for="editVideoTitle">Başlığı:</label>
			<input type="text" id="editVideoTitle" placeholder="Başlık girin" style="width:100px" title="Video Başlığı">
			<div class="me-modal-footer">
				<button type="button" onclick="updateVideo()">Güncelle</button>
				<button type="button" onclick="deleteVideo()">Kaldır</button>
				<button type="button" onclick="this.parentNode.parentNode.style.display='none'">Kapat</button>
			</div>
		</div>
    `;
    const toolbar = document.getElementById('toolbar');
    if (toolbar) {toolbar.appendChild(imageContainer);}
	var resimBtnCon = document.getElementById('medya-container');
	var resimBtn = document.getElementById('resimBtn');
	var resimDuzenle = document.getElementById('resimDuzenle');
	let offsetX = 0, offsetY = 0, isDragging = false;
	const dragHandles = document.querySelectorAll('.drag-handle');

	dragHandles.forEach(dragHandle => {
		dragHandle.addEventListener('mousedown', (e) => {
			e.preventDefault();
			isDragging = true;
			const menu = dragHandle.closest('.sagtusmenu');
			offsetX = e.clientX - menu.offsetLeft;
			offsetY = e.clientY - menu.offsetTop;
			menu.style.cursor = "move";
			const moveMenu = (e) => {
				if (isDragging) {
					menu.style.left = `${e.clientX - offsetX}px`;
					menu.style.top = `${e.clientY - offsetY}px`;
				}
			};

			const stopDragging = () => {
				isDragging = false;
				menu.style.cursor = "default";
				document.removeEventListener('mousemove', moveMenu);
				document.removeEventListener('mouseup', stopDragging);
			};

			document.addEventListener('mousemove', moveMenu);
			document.addEventListener('mouseup', stopDragging);
		});
	});

};

let currentImage = null;

function deleteImage(){
	if(currentImage){
		currentImage.parentNode.remove();
	}
	resimDuzenle.style.display = 'none';
}

function deleteVideo(){
	if(currentVideo){
		currentVideo.parentNode.remove();
	}
	videoDuzenle.style.display = 'none';
}

function updateImage() {
    const width = document.getElementById('editWidth').value;
    const widthtype = document.getElementById('editWidthType').value;
    const height = document.getElementById('editHeight').value;
    const heighttype = document.getElementById('editHeightType').value;
    const title = document.getElementById('editTitle').value;
    const align = document.getElementById('editAlign').value;
    if (currentImage) {
        currentImage.parentNode.style.width = width ? `${width}${widthtype}` : '250px';
        currentImage.parentNode.style.height = height ? `${height}${heighttype}` : '';
        currentImage.title = title ? title : 'Resim';
        currentImage.parentNode.style.margin = align === 'center' ? '0 auto' : align === 'right' ? '0 0 0 auto' : '0';
        currentImage.style.display = 'block';
    }
    resimDuzenle.style.display = 'none';
}

function previewImage(event) {
	const file = event.target.files[0];
	if (file) {
		const reader = new FileReader();
		reader.onload = function (e) {
			document.getElementById('previewImg').src = e.target.result;
			document.getElementById('imagePreview').style.display = 'block';
		};
		reader.readAsDataURL(file);
	}
}

function insertImage() {
    const url = document.getElementById('imageUrl').value;
    const file = document.getElementById('imageFile').files[0];
    const width = document.getElementById('imageWidth').value;
    const height = document.getElementById('imageHeight').value || ' ';
    const title = document.getElementById('imageTitle').value;
    const align = document.getElementById('imageAlign').value;
    let img = new Image();

    if (url) {
        img.src = url;
        finalizeImage(img, width, height, align, title);
    } else if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            img.src = e.target.result;
            finalizeImage(img, width, height, align, title);
        };
        reader.readAsDataURL(file);
    } else {
        console.log('URL veya dosya belirtmeniz gerekiyor.');
        return;
    }
	
	function finalizeImage(img, width, height, align, title) {
        const imageDiv = document.createElement('div');
        imageDiv.classList.add('elm-in-editor');
        imageDiv.contentEditable = 'false';
        imageDiv.style.width = `${width}px`;
        imageDiv.style.height = `${height}px`;
        imageDiv.style.margin = align === "center" ? "0 auto" : align === "left" ? "0" : "0 0 0 auto";
        const image = document.createElement('img');
        image.src = img.src;
        image.title = title;
        image.style.width = '100%';
        image.style.height = '100%';
        imageDiv.appendChild(image);
        savedSelection.insertNode(imageDiv);
        butonServis(imageDiv);
    }
    resetImageForm();
}

function resetImageForm() {
	document.getElementById('imageUrl').value = '';
	document.getElementById('imageFile').value = '';
	document.getElementById('previewImg').src = '';
	document.getElementById('imagePreview').style.display = 'none';
	document.getElementById('imageTitle').value = '';
	document.getElementById('imageWidth').value = 250;
	document.getElementById('imageHeight').value = '';
	document.getElementById('imageAlign').value = 'center';
	document.getElementById('resimModal').style.display = 'none';
}

editor.oncontextmenu = function (e) {
	const toolbarWidthPercentage = (parseFloat(window.getComputedStyle(toolbar).width) / window.innerWidth) * 100;
	const tolerance = 0.5; 
	if (e.ctrlKey && e.target.classList.contains('elm-in-editor')) {
		e.preventDefault(); // Diğer olayların engellenmesi
		const rightClickEvent = new MouseEvent('contextmenu', {
			bubbles: true,
			cancelable: true,
			view: window,
			button: 2,
			ctrlKey: true
		});
		e.target.querySelector('iframe').dispatchEvent(rightClickEvent);
	}

    if (e.ctrlKey && e.target.tagName === 'IFRAME') {
        e.preventDefault();
        currentVideo = e.target;
        const parentStyle = currentVideo.parentNode.style;
    
        // Width ayarı (px veya % kontrolü)
        const widthValue = parentStyle.width || '';
        document.getElementById('editVideoWidth').value = widthValue.replace(/px|%/g, '');
        const widthUnitMatch = widthValue.match(/[a-zA-Z%]+/);
        if (widthUnitMatch) {
            document.getElementById('editVideoWidthType').value = widthUnitMatch[0];
            document.getElementById('editVideoWidthType').dispatchEvent(new Event('change'));
        }
    
        // Height ayarı (px veya % kontrolü)
        const heightValue = parentStyle.height || '';
        document.getElementById('editVideoHeight').value = heightValue.replace(/px|%/g, '');
        const heightUnitMatch = heightValue.match(/[a-zA-Z%]+/);
        if (heightUnitMatch) {
            document.getElementById('editVideoHeightType').value = heightUnitMatch[0];
            document.getElementById('editVideoHeightType').dispatchEvent(new Event('change'));
        }
    
        // Diğer ayarlar
        document.getElementById('editVideoTitle').value = currentVideo.title || '';
        document.getElementById('editAlign').value = 
            parentStyle.margin === '0px' ? 'left' : 
            parentStyle.margin === '0px auto' ? 'center' : 
            parentStyle.margin === '0px 0px 0px auto' ? 'right' : 'center';
    
        videoDuzenle.style.top = `${Math.floor((window.innerHeight / 3.5) + window.scrollY)}px`;
        videoDuzenle.style.left = `${Math.floor((window.innerWidth / 2.6) + window.scrollX)}px`;
        videoDuzenle.style.display = 'flex';

    } else if (e.ctrlKey && e.target.tagName === 'IMG') {
        e.preventDefault();
        currentImage = e.target;
        const parentStyle = currentImage.parentNode.style;
    
        // Width ayarı (offsetWidth veya style.width kontrolü)
        document.getElementById('editWidth').value = currentImage.offsetWidth || '';
        const widthValue = parentStyle.width || '';
        const widthUnitMatch = widthValue.match(/[a-zA-Z%]+/);
        if (widthUnitMatch) {
            document.getElementById('editWidthType').value = widthUnitMatch[0];
            document.getElementById('editWidthType').dispatchEvent(new Event('change'));
        }
    
        // Height ayarı (offsetHeight veya style.height kontrolü)
        document.getElementById('editHeight').value = currentImage.parentNode.offsetHeight || '';
        const heightValue = parentStyle.height || '';
        const heightUnitMatch = heightValue.match(/[a-zA-Z%]+/);
        if (heightUnitMatch) {
            document.getElementById('editHeightType').value = heightUnitMatch[0];
            document.getElementById('editHeightType').dispatchEvent(new Event('change'));
        }
    
        // Diğer ayarlar
        document.getElementById('editTitle').value = currentImage.title || '';
        document.getElementById('editAlign').value = 
            parentStyle.margin === '0px' ? 'left' : 
            parentStyle.margin === '0px auto' ? 'center' : 
            parentStyle.margin === '0px 0px 0px auto' ? 'right' : 'center';
    
        resimDuzenle.style.top = `${Math.floor((window.innerHeight / 3.5) + window.scrollY)}px`;
        resimDuzenle.style.left = `${Math.floor((window.innerWidth / 2.6) + window.scrollX)}px`;
        resimDuzenle.style.display = 'flex';
    }
};

function previewVideo() {
    const videoUrl = document.getElementById('videoUrl').value;
    const videoPreview = document.getElementById('videoPreview');
    const previewIframe = document.getElementById('previewIframe');
    const videoIdMatch = videoUrl.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
    if (videoIdMatch && videoIdMatch[1]) {
        const videoId = videoIdMatch[1];
        previewIframe.src = `https://www.youtube.com/embed/${videoId}`;
        videoPreview.style.display = 'block';
    } else {
        alert('Geçerli URL girin.');
        previewIframe.src = '';
        videoPreview.style.display = 'none';
    }
}

function insertVideo() {
    const videoUrl = document.getElementById('videoUrl').value;
    const videoAlign = document.getElementById('videoAlign').value;
    const videoTitle = document.getElementById('videoTitle').value;
    const videoWidth = document.getElementById('videoWidth').value;
    const videoHeight = document.getElementById('videoHeight').value;
    const videoIdMatch = videoUrl.match(/(?:https?:\/\/)?(?:www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
    if (videoIdMatch && videoIdMatch[2]) {
        const videoId = videoIdMatch[2];
        const videoDiv = document.createElement('div');
        videoDiv.classList.add('elm-in-editor');
        videoDiv.contentEditable = 'false';
        videoDiv.style.width = `${videoWidth}px`;
        videoDiv.style.height = `${videoHeight}px`;
        videoDiv.style.margin = videoAlign === "center" ? "0 auto" : videoAlign === "left" ? "0" : "0 0 0 auto";
        const iframe = document.createElement('iframe');
        iframe.src = `https://www.youtube.com/embed/${videoId}`;
        iframe.title = `${videoTitle}`;
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        videoDiv.appendChild(iframe);
        savedSelection.insertNode(videoDiv);
        butonServis(videoDiv);
		resetVideoForm();
    } else {
        console.log('Geçersiz YouTube video URL’si');
    }	
}

function resetVideoForm() {
    document.getElementById('videoUrl').value = '';
    document.getElementById('videoAlign').value = 'center';
    document.getElementById('videoTitle').value = '';
    document.getElementById('videoWidth').value = '560';
    document.getElementById('videoHeight').value = '315';
    document.getElementById('previewIframe').src = '';
    document.getElementById('videoPreview').style.display = 'none';
	closeModal();
}

function updateVideo() {
    const width = document.getElementById('editVideoWidth').value;
    const widthtype = document.getElementById('editVideoWidthType').value;
    const height = document.getElementById('editVideoHeight').value;
    const heighttype = document.getElementById('editVideoHeightType').value;
    const title = document.getElementById('editVideoTitle').value;
    const align = document.getElementById('editVideoAlign').value;
    if (currentVideo) {
        currentVideo.parentNode.style.width = width ? `${width}${widthtype}` : '250px';
        currentVideo.parentNode.style.height = height ? `${height}${heighttype}` : '';
        currentVideo.title = title ? title : 'Video';
        if (align === 'left' || align === 'right') {
            currentVideo.parentNode.style.float = align;
        } else {
            currentVideo.parentNode.style.float = 'none';
        }
        currentVideo.style.display = align === 'center' ? 'block' : '';
        currentVideo.parentNode.style.margin = align === 'center' ? '0 auto' : '0';
    }
    videoDuzenle.style.display = 'none';
}

const elmsDivs = document.getElementsByClassName('elm-in-editor');
Array.from(elmsDivs).forEach(elmDiv => {butonServis(elmDiv);});

function butonServis(elmDiv) {
    // Önceki butonları temizleme fonksiyonu
    function clearExistingButtons() {
        const existingButtons = elmDiv.querySelectorAll('.btnSrvsBtn');
        existingButtons.forEach(button => button.remove());
    }

    // Butonları oluşturma fonksiyonu
    function createButton(html, title, position, clickHandler) {
        const button = document.createElement('button');
        button.type = "button";
        button.innerHTML = html;
        button.title = title;
        button.classList.add('btnSrvsBtn');
        Object.assign(button.style, position);
        button.addEventListener('click', clickHandler);
        return button;
    }

    // Butonları oluştur
    const buttons = {
        bottomRight: createButton('⏎', 'Altına Satır Ekle', 
            {bottom: '5px', right: '5px'}, (event) => {
                const newParagraph = document.createElement('p');
                newParagraph.innerHTML = '&nbsp;';
                elmDiv.parentNode.insertBefore(newParagraph, elmDiv.nextSibling);
                moveCursorToEnd(newParagraph);
                newParagraph.click();
                event.stopPropagation();
            }),
        
        topLeft: createButton('⏎', 'Üstüne Satır Ekle', 
            {top: '5px', left: '5px'}, (event) => {
                const newParagraph = document.createElement('p');
                newParagraph.innerHTML = '&nbsp;';
                elmDiv.parentNode.insertBefore(newParagraph, elmDiv);
                moveCursorToEnd(newParagraph);
                newParagraph.click();
                event.stopPropagation();
            }),
        
        topRight: createButton('✖', 'Öğeyi Sil', 
            {top: '5px', right: '5px'}, (event) => {
                elmDiv.remove();
                event.stopPropagation();
            }),
        
        bottomLeft: createButton('⚙', 'Ayarları Aç', 
            {bottom: '5px', left: '5px'}, (event) => {
                const rightClickEvent = new MouseEvent('contextmenu', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    button: 2,
                    ctrlKey: true
                });
                const divElm = elmDiv.firstElementChild;
                if (divElm?.tagName === 'TABLE') {
                    const selectedCell = elmDiv.querySelector('td.selectedcell');
                    const targetCell = selectedCell || elmDiv.querySelector('td');
                    targetCell?.dispatchEvent(rightClickEvent);
                } else {
                    const elements = elmDiv.querySelectorAll('img, iframe');
                    elements.forEach(element => {
                        element.dispatchEvent(rightClickEvent);
                    });
                }
                event.stopPropagation();
            })
    };

    // Mouseover eventi
    elmDiv.addEventListener('mouseover', function(event) {
        // Önceki butonları temizle
        clearExistingButtons();
        
        // Yeni butonları ekle
        for (const button of Object.values(buttons)) {
            elmDiv.appendChild(button);
        }
    });

    // Mouseout eventi
    elmDiv.addEventListener('mouseout', function(event) {
        // Eğer mouse elmDiv'den çıktıysa ve yeni hedef butonlardan biri değilse
        if (!elmDiv.contains(event.relatedTarget)) {
            clearExistingButtons();
        }
    });

    // İçerik editable ayarı
    elmDiv.addEventListener('mousemove', function(event) {
        if (elmDiv.firstElementChild) {
            elmDiv.firstElementChild.setAttribute('contenteditable', 'true');
        }
    });
}