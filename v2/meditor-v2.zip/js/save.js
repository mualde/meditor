function AddkaydetBtn() {
    const kaydetContainer = document.createElement('div');
    kaydetContainer.id = 'kaydet-container';
    kaydetContainer.innerHTML = `
		<button type="button" id="yenisayfaBtn" title="Yeni Ekle" onclick="newPost();">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#0d6efd"><path d="M440-240h80v-120h120v-80H520v-120h-80v120H320v80h120v120ZM240-80q-33 0-56.5-23.5T160-160v-640q0-33 23.5-56.5T240-880h320l240 240v480q0 33-23.5 56.5T720-80H240Zm280-520v-200H240v640h480v-440H520ZM240-800v200-200 640-640Z"/></svg>
            </span>
        </button>
        <button type="button" id="kaydetBtn" title="Kaydet" onclick="savePost();" style="box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#198754"><path d="M840-680v480q0 33-23.5 56.5T760-120H200q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h480l160 160Zm-80 34L646-760H200v560h560v-446ZM480-240q50 0 85-35t35-85q0-50-35-85t-85-35q-50 0-85 35t-35 85q0 50 35 85t85 35ZM240-560h360v-160H240v160Zm-40-86v446-560 114Z"/></svg>
            </span>
        </button>
		<button type="button" id="sayfasilBtn" title="Sil" onclick="deletePost();">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#dc3545"><path d="M240-800v200-200 640-9.5 9.5-640Zm0 720q-33 0-56.5-23.5T160-160v-640q0-33 23.5-56.5T240-880h320l240 240v174q-19-7-39-10.5t-41-3.5v-120H520v-200H240v640h254q8 23 20 43t28 37H240Zm396-20-56-56 84-84-84-84 56-56 84 84 84-84 56 56-83 84 83 84-56 56-84-83-84 83Z"/></svg>
            </span>
        </button>
    `;

    if (toolbar) {toolbar.appendChild(kaydetContainer);}
}