function AddTableBtn() {
    const tableContainer = document.createElement('div');
    tableContainer.id = 'table-container';
    tableContainer.innerHTML = `
        <button type="button" id="tableBtn" title="Tablo Ekle" onclick="openModal('tableModal')" onmousedown="quickTableMenu();">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm240-240H200v160h240v-160Zm80 0v160h240v-160H520Zm-80-80v-160H200v160h240Zm80 0h240v-160H520v160ZM200-680h560v-80H200v80Z"/></svg>
            </span>
        </button>
		<div id="tableModal" class="me-modal" style="display:none">
			<div id="me-modal-content" class="me-modal-content">
				<div class="me-modal-header">
					<h5 class="me-modal-title">Tablo Ekle</h5>
				</div>
				<div class="me-modal-body">
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Başlığı </span>
						<br>
						<input type="text" id="table-title" placeholder="Tablo Başlık ekleyin (isteğe bağlı)" style="width:350px">
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Yapısı </span>
						<br>
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-320v-80h80v80h-80Zm160 640v-720h80v720h-80Zm160 0v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-320v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Z"/></svg><input type="number" id="table-rows" min="1" value="3" style="width:50px" title="Sütun Sayısı">
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h720v80H120Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-160v-80h80v80h-80Z"/></svg><input type="number" id="table-cols" min="1" value="3" style="width:50px" title="Satır Sayısı">
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z"/></svg>
                        <input type="number" id="table-width" value="400" style="width:80px" title="Tablu Genişliği">
                        <select id="table-width-type" title="widthtype" style="width:50px" onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
                            <option value="px" selected>Px</option>
                            <option value="%">%</option>
                        </select>

						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M320-80 160-240l160-160 57 56-64 64h334l-63-64 56-56 160 160L640-80l-57-56 64-64H313l63 64-56 56ZM200-480v-400h80v400h-80Zm240 0v-400h80v400h-80Zm240 0v-400h80v400h-80Z"/></svg>
						<select id="table-alignment" style="width:70px" title="Bulunduğu Yer">
							<option value="center">Orta</option>
							<option value="left">Sol</option>
							<option value="right">Sağ</option>
						</select>
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Stili </span>
						<label for="border-width" title="Tablonun Stili">
							<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-120v-80h80v80h-80Zm160 0v-80h80v80h-80Zm160 0v-80h80v80h-80Zm160 0v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80ZM120-120v-720h720v80H200v640h-80Z"/></svg>
						</label>
						<input type="number" title="Kenar Kalınlığı" id="border-width" value="1" style="width:50px">
						<select id="border-style" title="Kenar Tipi" style="width:70px">
							<option value="solid">―――</option>
							<option value="dashed">- - - - -</option>
							<option value="dotted">٠٠٠٠٠٠</option>
						</select>
						<input type="color" title="Kenar Rengi" id="border-color" value="${negColor(rgbToHex(bodyBgColor))}" list>
					</div>
				</div>
				<div class="me-modal-footer">
					<button type="button" onclick="createTable()">Tablo Oluştur</button>
					<button type="button" onclick="cancelModal();">İptal Et</button>
				</div>
			</div>
		</div>
		<div id="editTableModal" class="me-modal" style="display:none">
			<div id="me-modal-content" class="me-modal-content">
				<div class="me-modal-header">
					<h5 class="me-modal-title">Tabloyu Düzenle</h5>
				</div>
				<div class="me-modal-body">
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Başlığı </span>
						<br>
						<input type="text" id="edit-table-title" placeholder="Tablo Başlık ekleyin (isteğe bağlı)" style="width:350px">
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Yapısı </span>
						<br>
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-320v-80h80v80h-80Zm160 640v-720h80v720h-80Zm160 0v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-320v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Z"/></svg></i><input type="number" id="edit-table-rows" min="1" value="3" style="width:50px" title="Sütun Sayısı">
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h720v80H120Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-320v-80h80v80h-80Zm0-160v-80h80v80h-80Z"/></svg><input type="number" id="edit-table-cols" min="1" value="3" style="width:50px" title="Satır Sayısı">
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z"/></svg>
                        <input type="number" id="edit-table-width" value="600" style="width:80px" title="Tablu Genişliği">
                        <select id="edit-table-width-type" title="widthtype" style="width:50px" onchange="if (this.value === '%') {if(this.previousElementSibling.value > 100){this.previousElementSibling.value = '100';}; this.previousElementSibling.max ='100'}else{this.previousElementSibling.max = null}">
                            <option value="px" selected>Px</option>
                            <option value="%">%</option>
                        </select>

						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M320-80 160-240l160-160 57 56-64 64h334l-63-64 56-56 160 160L640-80l-57-56 64-64H313l63 64-56 56ZM200-480v-400h80v400h-80Zm240 0v-400h80v400h-80Zm240 0v-400h80v400h-80Z"/></svg>
						<select id="edit-table-alignment" style="width:70px" title="Bulunduğu Yer">
							<option value="center">Orta</option>
							<option value="left">Sol</option>
							<option value="right">Sağ</option>
						</select>
					</div>
					<br>
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Tablo Stili </span>
						<label for="border-width" title="Tablonun Stili">
							<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-120v-80h80v80h-80Zm160 0v-80h80v80h-80Zm160 0v-80h80v80h-80Zm160 0v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80ZM120-120v-720h720v80H200v640h-80Z"/></svg>
						</label>
						<input type="number" title="Kenar Kalınlığı" id="edit-border-width" value="1" style="width:50px">
						<select id="edit-border-style" title="Kenar Tipi" style="width:70px">
							<option value="solid">―――</option>
							<option value="dashed">- - - - -</option>
							<option value="dotted">٠٠٠٠٠٠</option>
						</select>
						<input type="color" title="Kenar Rengi" id="edit-border-color" value="#000000" list>
					</div>
				</div>
				<div class="me-modal-footer">
					<button type="button" onclick="updateTable()">Güncelle</button>
					<button type="button" onclick="cancelModal();">İptal Et</button>
				</div>
			</div>
		</div>
		<div id="editCellModal" class="me-modal" style="display:none">
			<div id="me-modal-content" class="me-modal-content">
				<div class="me-modal-header">
					<h5 class="me-modal-title">Hücreyi Düzenle</h5>
				</div>
				<div class="me-modal-body">
					<!-- Hücre İçeriği -->
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Hücre İçeriği </span>
						<br>
						<input type="text" id="edit-cell-content" placeholder="Hücre içeriğini buraya yazın" style="width:350px">
					</div>
					<br>
					<!-- Hücre Stili -->
					<div class="me-form-group" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; position: relative;">
						<span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Hücre Stili </span>
						<br>

						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M346-140 100-386q-10-10-15-22t-5-25q0-13 5-25t15-22l230-229-106-106 62-65 400 400q10 10 14.5 22t4.5 25q0 13-4.5 25T686-386L440-140q-10 10-22 15t-25 5q-13 0-25-5t-22-15Zm47-506L179-432h428L393-646Zm399 526q-36 0-61-25.5T706-208q0-27 13.5-51t30.5-47l42-54 44 54q16 23 30 47t14 51q0 37-26 62.5T792-120Z"/></svg><input type="color" id="edit-cell-bg-color" value="#ffffff" title="Hücre Arka Plan Rengi" list>
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M167-120q-21 5-36.5-10.5T120-167l40-191 198 198-191 40Zm191-40L160-358l458-458q23-23 57-23t57 23l84 84q23 23 23 57t-23 57L358-160Zm317-600L261-346l85 85 414-414-85-85Z"/></svg><input type="color" id="edit-cell-text-color" value="#000000" title="Hücre Yazı Rengi" list>
						<svg height="24px" viewBox="0 -960 960 960" width="24px"><path d="M280-160v-520H80v-120h520v120H400v520H280Zm360 0v-320H520v-120h360v120H760v320H640Z"/></svg><input type="number" id="edit-cell-font-size" value="14" style="width:50px" title="Yazı Boyutu">
						<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-200h560v-560H200v560Zm-80 80v-720h720v720H120Zm160-320v-80h80v80h-80Zm160 160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm160 160v-80h80v80h-80Z"/></svg><input type="number" id="edit-cell-border-width" value="1" style="width:50px" title="Kenar Kalınlığı"><input type="color" id="edit-cell-border-color" value="#000000" title="Kenar Rengi" list>
					</div>
					<br>
				</div>
				<div class="me-modal-footer">
					<button type="button" onclick="updateCell()">Hücreyi Güncelle</button>
					<button type="button" onclick="cancelModal();">İptal Et</button>
				</div>
			</div>
		</div>
		<div id="tablosagtusmenu" class="sagtusmenu" style="display:none;width:300px">
			<div id="dragHandle" class="drag-handle" style="width:100%;text-align:center">
				<span style="font-weight:bold">Hücre Ayarı Menüsü</span> 
			</div>
			<button type="button" title="Hücre Biçimlendir" onclick="this.parentNode.style.display='none';getDataFromCell();openModal('editCellModal');">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M440-120v-240h80v80h320v80H520v80h-80Zm-320-80v-80h240v80H120Zm160-160v-80H120v-80h160v-80h80v240h-80Zm160-80v-80h400v80H440Zm160-160v-240h80v80h160v80H680v80h-80Zm-480-80v-80h400v80H120Z"/></svg>
			</button>
			<br>
			<button type="button" title="Üst Tarafa Satır Ekle" onclick="addRowUp();">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-160h560v-240H200v240Zm640 80H120v-720h160v80h-80v240h560v-240h-80v-80h160v720ZM480-480Zm0 80v-80 80Zm0 0Zm-40-240v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z"/></svg>
			</button>
			<button type="button" title="Alt Tarafa Satır Ekle" onclick="addRowDown();">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-560h560v-240H200v240Zm-80 400v-720h720v720H680v-80h80v-240H200v240h80v80H120Zm360-320Zm0-80v80-80Zm0 0ZM440-80v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z"/></svg>
			</button>
			<button type="button" title="Sola Sütun Ekle" onclick="addColumnLeft();">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M800-200v-560H560v560h240Zm-640 80v-160h80v80h240v-560H240v80h-80v-160h720v720H160Zm320-360Zm80 0h-80 80Zm0 0ZM160-360v-80H80v-80h80v-80h80v80h80v80h-80v80h-80Z"/></svg>
			</button>
			<button type="button" title="Sağa Sütun Ekle" onclick="addColumnRight();">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M160-760v560h240v-560H160ZM80-120v-720h720v160h-80v-80H480v560h240v-80h80v160H80Zm400-360Zm-80 0h80-80Zm0 0Zm320 120v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z"/></svg>
			</button>
			<div style="width:100%;text-align:center"></div>
			<button type="button" id="delete-row" onclick="hucreBirlestir()" title="Hücreleri Birleştir">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-240h80v160h160v80H120Zm480 0v-80h160v-160h80v240H600ZM287-327l-57-56 57-57H80v-80h207l-57-57 57-56 153 153-153 153Zm386 0L520-480l153-153 57 56-57 57h207v80H673l57 57-57 56ZM120-600v-240h240v80H200v160h-80Zm640 0v-160H600v-80h240v240h-80Z"/></svg>
			</button>
			<button type="button" id="delete-row" onclick="yatayBol()" title="Hücreyi Yatay Böl">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M440-160v-304L240-664v104h-80v-240h240v80H296l224 224v336h-80Zm154-376-58-58 128-126H560v-80h240v240h-80v-104L594-536Z"/></svg>
			</button>
			<div style="width:100%;text-align:center"></div>
			<button type="button" id="delete-row" onclick="deleteRow()" title="Satır Sil">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z"/></svg>x
			</button>
			<button type="button" id="delete-column" onclick="deleteColumn()" title="Sütun Sil">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M480-144 336-288l51-51 57 57v-396l-57 57-51-51 144-144 144 144-51 51-57-57v396l57-57 51 51-144 144Z"/></svg>x
			</button>
            <div style="width:100%;text-align:center"></div>
            <button type="button" id="delete-column" onclick="this.parentNode.style.display='none';" title="Hücre Menüsünü Kapat">
				Menüyü Kapat
			</button>
		</div>
    `;

    if (toolbar) {toolbar.appendChild(tableContainer);}
	let offsetX = 0, offsetY = 0, isDragging = false;
	const dragHandles = document.querySelectorAll('.drag-handle');
	dragHandles.forEach(dragHandle => {
		dragHandle.addEventListener('mousedown', (e) => {
			e.preventDefault();
			isDragging = true;
			const menu = dragHandle.closest('.sagtusmenu');
			offsetX = e.clientX - menu.offsetLeft;
			offsetY = e.clientY - menu.offsetTop;
			menu.style.cursor = "move";
			const moveMenu = (e) => {
				if (isDragging) {
					menu.style.left = `${e.clientX - offsetX}px`;
					menu.style.top = `${e.clientY - offsetY}px`;
				}
			};
			const stopDragging = () => {
				isDragging = false;
				menu.style.cursor = "default";
				document.removeEventListener('mousemove', moveMenu);
				document.removeEventListener('mouseup', stopDragging);
			};
			document.addEventListener('mousemove', moveMenu);
			document.addEventListener('mouseup', stopDragging);
		});
	});
}

let infoDisplay = null;
function quickTableMenu(e) {
    const tableBtnCon = document.getElementById('table-container');
    if (!tableBtnCon) {
        console.error("Table container bulunamadı!");
        return;
    }
    const existingMenu = document.getElementById('quick-table-menu');
    if (existingMenu) {
        existingMenu.remove();
    }
	const quickTableMenu = document.createElement('div');
	quickTableMenu.id = 'quick-table-menu';
	quickTableMenu.style.display = 'grid';
	quickTableMenu.style.gridTemplateColumns = 'repeat(9, 15px)'; 
	quickTableMenu.style.gap = '0'; 
	quickTableMenu.style.position = 'absolute';
	quickTableMenu.style.backgroundColor = '#fff';
	quickTableMenu.style.border = '1px solid #ccc';
    createQuickTableMenu(quickTableMenu);
	tableBtnCon.appendChild(quickTableMenu);
	infoDisplay = document.createElement('span');
	infoDisplay.id = 'infoDisplay';
    infoDisplay.style.cssText = 'pointer-events: none; position: relative; margin-top: -93px; margin-left: 37px; font-size: 25pt; opacity: 0.3;';
	quickTableMenu.appendChild(infoDisplay);
	infoDisplay = document.getElementById('infoDisplay');
}
function createQuickTableMenu(quickTableMenu) {
	let startCell = null;
	let endCell = null;
    const gridSize = 9;
    for (let row = 1; row <= gridSize; row++) {
        for (let col = 1; col <= gridSize; col++) {
            const button = document.createElement('input');
            button.type = 'button';
            button.className = 'quick-table-cell';
            button.dataset.row = row;
            button.dataset.col = col;
            button.style.width = '15px';
            button.style.height = '15px';
            button.title = col + 'X' + row; 
            button.addEventListener('mouseover', (e) => {
                const hoverRow = parseInt(e.target.dataset.row);
                const hoverCol = parseInt(e.target.dataset.col);
                quickTableMenu.querySelectorAll('.quick-table-cell').forEach((cell) => {
                    const cellRow = parseInt(cell.dataset.row);
                    const cellCol = parseInt(cell.dataset.col);
                    if (cellRow <= hoverRow && cellCol <= hoverCol) {
                        cell.style.backgroundColor = 'lightblue';
                    } else {
                        cell.style.backgroundColor = '';
                    }
                });
                infoDisplay.innerHTML = e.target.title;
            });
			button.addEventListener('mouseup', (e) => {
                const endCell = e.target;
                if (startCell) {
                    const startRow = parseInt(startCell.dataset.row);
                    const startCol = parseInt(startCell.dataset.col);
                    const endRow = parseInt(endCell.dataset.row);
                    const endCol = parseInt(endCell.dataset.col);
                    const rows = Math.abs(endRow - startRow) + 1;
                    const cols = Math.abs(endCol - startCol) + 1;
                    createTableQuick(rows, cols);
                    quickTableMenu.remove();
					infoDisplay.remove();
                }
            });
            
            quickTableMenu.appendChild(button);
        }
    }
    const firstCell = quickTableMenu.querySelector('[data-row="1"][data-col="1"]');
    if (firstCell) {
        startCell = firstCell;
        firstCell.classList.add('selectedbtn');
    }
}
function createTableQuick(rows, cols) {
    const tableDiv = document.createElement('div');
    tableDiv.className = 'elm-in-editor';
    tableDiv.contentEditable = 'false';
    tableDiv.style.cssText = `width: 650px; margin: 0 auto;`;
    const table = document.createElement('table');
    table.contentEditable = 'true';
    table.style.cssText = `border-collapse: collapse;border: 1px solid black; width: 100%;height: 100%;`;
    let trhight = 0;
    for (let i = 0; i < rows; i++) {
        trhight += 30;
        const tr = document.createElement('tr');
        for (let j = 0; j < cols; j++) {
            const td = document.createElement('td');
            td.style.border = `1px solid ${negColor(bodyBgColor)}`;
            td.innerHTML = '&nbsp;';
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    tableDiv.style.height = trhight+'px';
    tableDiv.appendChild(table);
    savedSelection.insertNode(tableDiv);
    butonServis(tableDiv);
}
function createTable() {
    const title = document.getElementById('table-title').value;
    const rows = parseInt(document.getElementById('table-rows').value);
    const cols = parseInt(document.getElementById('table-cols').value);
    const width = parseInt(document.getElementById('table-width').value);
    const widthType = document.getElementById('table-width-type').value;
    const borderWidth = parseInt(document.getElementById('border-width').value);
    const borderColor = document.getElementById('border-color').value;
    const borderStyle = document.getElementById('border-style').value;
    const align = document.getElementById('table-alignment').value;
    const tableDiv = document.createElement('div');
    tableDiv.className = 'elm-in-editor';
    tableDiv.contentEditable = 'false';
    tableDiv.style.cssText = `width: ${width}${widthType}; margin: ${align === "center" ? "0 auto" : align === "left" ? "0" : "0 0 0 auto"};`;
    const table = document.createElement('table');
    table.contentEditable = 'true';
    if (title) {const caption = document.createElement('caption'); caption.textContent = title;table.appendChild(caption);}
    let trhight = 0;
    table.style.cssText = `border-collapse: collapse; border: ${borderWidth}px ${borderStyle} ${borderColor}; width: 100%; height: 100%;`;
    for (let i = 0; i < rows; i++) {trhight += 30;const tr = document.createElement('tr');for (let j = 0; j < cols; j++) {const td = document.createElement('td');td.style.border = `1px solid ${negColor(bodyBgColor)}`;td.innerHTML = '&nbsp;';tr.appendChild(td);}table.appendChild(tr);}
    tableDiv.style.height = trhight+'px';
    tableDiv.appendChild(table);
    savedSelection.insertNode(tableDiv);
    butonServis(tableDiv);
    closeModal();
}
function getDataFromTable(table) {
	document.getElementById('edit-table-title').value = table.querySelector('caption') ? table.querySelector('caption').innerText : '';
	document.getElementById('edit-table-rows').value = table.rows.length;
	document.getElementById('edit-table-cols').value = table.rows[0] ? table.rows[0].cells.length : 0;
	document.getElementById('edit-table-alignment').value = table.parentNode.style.margin === '0px' ? 'left' : table.parentNode.style.margin === '0px auto' ? 'center' : table.parentNode.style.margin === '0px 0px 0px auto' ? 'right' : 'center';
	document.getElementById('edit-table-width').value = table.parentNode.style.width.replace('px','').replace('%','');
	document.getElementById('edit-table-width-type').value = table.parentNode.style.width.match(/[a-zA-Z%]+/)[0], document.getElementById('edit-table-width-type').dispatchEvent(new Event('change'));
	document.getElementById('edit-border-width').value = parseInt(window.getComputedStyle(table).borderWidth);
	document.getElementById('edit-border-style').value = window.getComputedStyle(table).borderStyle;
	document.getElementById('edit-border-color').value = rgbToHex(window.getComputedStyle(table).borderColor);
}
function updateTable() {
    const title = document.getElementById('edit-table-title').value;
    const rows = parseInt(document.getElementById('edit-table-rows').value) || 1;
    const cols = parseInt(document.getElementById('edit-table-cols').value) || 1;
    const width = parseInt(document.getElementById('edit-table-width').value) || 500;
    const widthType = document.getElementById('edit-table-width-type').value;
    const borderWidth = parseInt(document.getElementById('edit-border-width').value) || 1;
    const borderColor = document.getElementById('edit-border-color').value || "black";
    const borderStyle = document.getElementById('edit-border-style').value || "solid";
    const alignment = document.getElementById('edit-table-alignment').value || "center";
    selectedTable.parentNode.style.width = `${width+widthType}`;
    selectedTable.style.border = `${borderWidth}px ${borderStyle} ${borderColor}`;
    selectedTable.parentNode.style.margin = alignment === "center" ? "0 auto" : alignment === "left" ? "0" : "0 0 0 auto";
    let caption = selectedTable.querySelector('caption');
    if (caption) {caption.innerText = title;} else {selectedTable.insertAdjacentHTML('afterbegin', `<caption>${title}</caption>`);}
    while (selectedTable.rows.length < rows) {const row = selectedTable.insertRow();for (let i = 0; i < cols; i++) {const cell = row.insertCell();cell.innerHTML = "&nbsp;";cell.style = 'border: 1px solid black';}}
    while (selectedTable.rows.length > rows) {selectedTable.deleteRow(selectedTable.rows.length - 1);}
    for (let row of selectedTable.rows) {while (row.cells.length < cols) {const cell = row.insertCell();cell.innerHTML = "&nbsp;";cell.style = 'border: 1px solid black';}while (row.cells.length > cols) {row.deleteCell(row.cells.length - 1);}}
    closeModal();
}
function getDataFromCell() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const selectedCell = selectedCells[0]; // Eğer bir hücre seçildiyse, ilkini alıyoruz.

    if (selectedCells.length === 1) {
        document.getElementById('edit-cell-content').value = selectedCell.innerHTML;document.getElementById('edit-cell-content').disabled = false;
    }else{
		document.getElementById('edit-cell-content').value = '##Çoklu Şeçim##';document.getElementById('edit-cell-content').disabled = true;
	}
	const style = selectedCell.getAttribute('style') || '';
	const bgColorMatch = style.match(/(?:^|;)\s*background-color:\s*([^;]+)/);document.getElementById('edit-cell-bg-color').value = bgColorMatch ? rgbToHex(bgColorMatch[1]) : '#FFFFFF';
	const textColorMatch = style.match(/(?:^|;)\s*color:\s*([^;]+)/);document.getElementById('edit-cell-text-color').value = textColorMatch ? rgbToHex(textColorMatch[1]) : '#000000';
	const fontSizeMatch = style.match(/(?:^|;)\s*font-size:\s*([^;]+)/);document.getElementById('edit-cell-font-size').value = fontSizeMatch ? parseInt(fontSizeMatch[1]) : 14;
	const borderWidthMatch = style.match(/(?:^|;)\s*border-width:\s*([^;]+)/);document.getElementById('edit-cell-border-width').value = borderWidthMatch ? parseInt(borderWidthMatch[1]) : 1;
	const borderColorMatch = style.match(/border:\s*\d+px\s+\w+\s+(rgb\([^)]+\)|#[a-fA-F0-9]{3,6});?/);document.getElementById('edit-cell-border-color').value = borderColorMatch ? rgbToHex(borderColorMatch[1]) : '#000000';
}
function updateCell() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    if (selectedCells.length > 0) {
        selectedCells.forEach(selectedCell => {
            if (selectedCells.length === 1) {selectedCell.innerHTML = document.getElementById('edit-cell-content').value;}
			
            selectedCell.style.backgroundColor = document.getElementById('edit-cell-bg-color').value;
            selectedCell.style.color = document.getElementById('edit-cell-text-color').value;
            selectedCell.style.fontSize = `${document.getElementById('edit-cell-font-size').value}px`;
            selectedCell.style.borderWidth = `${document.getElementById('edit-cell-border-width').value}px`;
            selectedCell.style.borderColor = hexToRgb(document.getElementById('edit-cell-border-color').value);
			selectedCell.classList.remove('selectedcell');
        });
        closeModal();
    }
}
function addRowUp() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    if (selectedCells.length > 0) {
        const topMostCell = getTopMostCell(selectedCells);
        const selectedRow = topMostCell.parentElement;
        const newRow = selectedRow.cloneNode(false);
        selectedRow.parentElement.insertBefore(newRow, selectedRow);
        const cellCount = selectedRow.children.length;
        for (let i = 0; i < cellCount; i++) {
            const newCell = document.createElement('td');
            newCell.style = 'border: 1px solid black';
            newCell.innerHTML = '&nbsp;';
            newRow.appendChild(newCell);
        }
        newRow.querySelectorAll('td').forEach(cell => {
            cell.classList.remove('selectedcell');
        });
    }
}

function addRowDown() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    if (selectedCells.length > 0) {
        const bottomMostCell = getBottomMostCell(selectedCells);
        const selectedRow = bottomMostCell.parentElement;
        const newRow = selectedRow.cloneNode(false);
        selectedRow.parentElement.insertBefore(newRow, selectedRow.nextSibling);
        const cellCount = selectedRow.children.length;
        for (let i = 0; i < cellCount; i++) {
            const newCell = document.createElement('td');
            newCell.style = 'border: 1px solid black';
            newCell.innerHTML = '&nbsp;';
            newRow.appendChild(newCell);
        }
        newRow.querySelectorAll('td').forEach(cell => {
            cell.classList.remove('selectedcell');
        });
    }
}

function addColumnLeft() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    if (selectedCells.length > 0) {
        const leftMostCell = getLeftMostCell(selectedCells);
        const columnIndex = Array.from(leftMostCell.parentElement.children).indexOf(leftMostCell);
        const rows = leftMostCell.parentElement.parentElement.children;
        Array.from(rows).forEach(row => {
            const newCell = row.insertBefore(document.createElement('td'), row.children[columnIndex]);
            newCell.style = 'border: 1px solid black';
            newCell.innerHTML = '&nbsp;';
            newCell.classList.remove('selectedcell');
        });
    }
}

function addColumnRight() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    if (selectedCells.length > 0) {
        const rightMostCell = getRightMostCell(selectedCells);
        const columnIndex = Array.from(rightMostCell.parentElement.children).indexOf(rightMostCell);
        const rows = rightMostCell.parentElement.parentElement.children;
        Array.from(rows).forEach(row => {
            const newCell = document.createElement('td');
            row.insertBefore(newCell, row.children[columnIndex + 1]);
            newCell.style = 'border: 1px solid black';
            newCell.innerHTML = '&nbsp;';
            newCell.classList.remove('selectedcell');
        });
    }
}

function getTopMostCell(selectedCells) {
    return Array.from(selectedCells).reduce((topMost, current) => {
        return current.getBoundingClientRect().top < topMost.getBoundingClientRect().top ? current : topMost;
    });
}

function getBottomMostCell(selectedCells) {
    return Array.from(selectedCells).reduce((bottomMost, current) => {
        return current.getBoundingClientRect().bottom > bottomMost.getBoundingClientRect().bottom ? current : bottomMost;
    });
}

function getLeftMostCell(selectedCells) {
    return Array.from(selectedCells).reduce((leftMost, current) => {
        return current.getBoundingClientRect().left < leftMost.getBoundingClientRect().left ? current : leftMost;
    });
}

function getRightMostCell(selectedCells) {
    return Array.from(selectedCells).reduce((rightMost, current) => {
        return current.getBoundingClientRect().right > rightMost.getBoundingClientRect().right ? current : rightMost;
    });
}

function deleteRow() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const processedRows = new Set();
    selectedCells.forEach(cell => {
        const row = cell.parentElement;
        if (row && !processedRows.has(row)) {
            processedRows.add(row);
            row.remove();
        }
    });
	 document.getElementById('tablosagtusmenu').style.display='none';
}

function deleteColumn() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const table = selectedCells[0]?.closest('table');
    const processedColumns = new Set();
    if (table) {
        selectedCells.forEach(cell => {
            const columnIndex = Array.from(cell.parentElement.children).indexOf(cell);
            if (columnIndex !== -1 && !processedColumns.has(columnIndex)) {
                processedColumns.add(columnIndex);
                Array.from(table.rows).forEach(row => {
                    const targetCell = row.children[columnIndex];
                    if (targetCell) {
                        targetCell.remove();
                    }
                });
            }
        });
    }
	 document.getElementById('tablosagtusmenu').style.display='none';
}
document.addEventListener('contextmenu', function(event) {
    const cell = event.target.closest('td, th');
    const etName = event.target.tagName;
    if (cell && (etName === 'TD' || etName === 'TH')) {
        const isCtrlPressed = event.ctrlKey;
        const isSelected = cell.classList.contains('selectedcell');
        if (isCtrlPressed && !isSelected) {
            event.preventDefault();
            selectedTable = event.target.closest('table');
            getDataFromTable(selectedTable);
            openModal('editTableModal');
        }
    }

    if (cell && event.ctrlKey && cell.classList.contains('selectedcell')){
        event.preventDefault(); 
            const tstMenu = document.getElementById('tablosagtusmenu');	
            tstMenu.style.top = `${Math.floor((window.innerHeight/3.5)+window.scrollY)}px`; 
            tstMenu.style.left = `${Math.floor((window.innerWidth/2.6)+window.scrollX)}px`;
            tstMenu.style.display = 'flex';
    } ;
});

document.addEventListener('click', function (e) {
	const quickTableMenu = document.getElementById('quick-table-menu');if (quickTableMenu && !quickTableMenu.contains(e.target)) {quickTableMenu.remove();infoDisplay.remove();}
	if (e.target.closest('td')) {
		if(e.ctrlKey){const cell = e.target;cell.classList.toggle('selectedcell');}
		document.querySelectorAll('table').forEach(table => {table.classList.remove('selectedtable');});
		e.target.closest('table').classList.add('selectedtable');
	}
    if (!e.target.closest('table')) {
        document.querySelectorAll('table').forEach(table => {
            table.classList.remove('selectedtable');
        });
    }    
});

document.addEventListener('dblclick', function(event) {
    if (event.target.tagName.toLowerCase() === 'td') {
        event.target.classList.toggle('selectedcell');
    }
});

function dikeyBirlestir() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const firstCell = selectedCells[0];
    const cellContents = [];
    let totalRowSpan = selectedCells.length;
    let totalRowSpanGreaterThanOne = 0;
    selectedCells.forEach(cell => {
        cellContents.push(cell.innerHTML);
        if (cell.rowSpan > 1) {
            totalRowSpanGreaterThanOne += cell.rowSpan - 1;
        }
        cell.classList.remove('selectedcell');
    });
    firstCell.setAttribute('rowspan', totalRowSpan + totalRowSpanGreaterThanOne);
    firstCell.innerHTML = cellContents.join(' ');
    selectedCells.forEach(cell => {
        if (cell !== firstCell) {
            const row = cell.parentElement;
            row.deleteCell(cell.cellIndex);
        }
    });
    document.getElementById('tablosagtusmenu').style.display = 'none';
}

function yatayBirlestir() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const firstCell = selectedCells[0];
    const cellContents = [];
    let totalColSpan = selectedCells.length;
    let totalColSpanGreaterThanOne = 0;
    selectedCells.forEach(cell => {
        cellContents.push(cell.innerHTML);
        if (cell.colSpan > 1) {
            totalColSpanGreaterThanOne += cell.colSpan - 1;
        }
        cell.classList.remove('selectedcell');
    });
    firstCell.setAttribute('colspan', totalColSpan + totalColSpanGreaterThanOne);
    firstCell.innerHTML = cellContents.join(' ');
    selectedCells.forEach(cell => {
        if (cell !== firstCell) {
            const row = cell.parentElement;
            row.deleteCell(cell.cellIndex);
        }
    });
    document.getElementById('tablosagtusmenu').style.display = 'none';
}

function hucreBirlestir() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const firstParent = selectedCells[0].parentNode;
    for (let i = 1; i < selectedCells.length; i++) {
        if (selectedCells[i].parentNode !== firstParent) {
			dikeyBirlestir();
        }else{
			yatayBirlestir();
		}
    }
}

function yatayBol() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const selectedTable = document.querySelector('.selectedtable');
    if (selectedCells.length === 0) {
        alert("Lütfen bölmek istediğiniz hücreyi seçin.");
        return;
    }
    selectedCells.forEach((cell) => {
        const row = cell.parentElement;
        const colIndex = Array.from(row.children).indexOf(cell);
        let colSpan = parseFloat(cell.getAttribute('colspan')) || 1;

        if (colSpan > 1) {
            const intColSpan = Math.floor(colSpan);
            const newColSpan = Math.floor(intColSpan / 2);
            const remainingColSpan = intColSpan - newColSpan;
            cell.setAttribute('colspan', newColSpan);
            const newCell = document.createElement('td');
            newCell.setAttribute('colspan', remainingColSpan);
            newCell.style= "border: 1px solid black";
            newCell.innerHTML = "&nbsp;";
            row.insertBefore(newCell, cell.nextSibling);
        } else {
            const newCell = document.createElement('td');
            newCell.innerHTML = "&nbsp;";
            newCell.style= "border: 1px solid black";
            row.insertBefore(newCell, cell.nextSibling);
            const rows = Array.from(selectedTable.rows);
            rows.forEach((currentRow) => {
                if (currentRow !== row) {
                    const targetCell = currentRow.cells[colIndex];
                    if (targetCell) {
                        const currentColSpan = parseInt(targetCell.getAttribute('colspan')) || 1;
                        targetCell.setAttribute('colspan', currentColSpan + 1);
                    }
                }
            });
        }
        cell.classList.remove('selectedcell');
    });
    document.getElementById('tablosagtusmenu').style.display = 'none';
}

function dikeyBol() {
    const selectedCells = document.querySelectorAll('.selectedcell');
    const selectedTable = document.querySelector('.selectedtable');
    if (selectedCells.length === 0) {
        alert("Lütfen bölmek istediğiniz hücreyi seçin.");
        return;
    }
    selectedCells.forEach((cell) => {
        const row = cell.parentElement;
        const colIndex = Array.from(row.children).indexOf(cell);
        let rowSpan = parseFloat(cell.getAttribute('rowspan')) || 1;
        if (rowSpan > 1) {
            const intRowSpan = Math.floor(rowSpan);
            const newRowSpan = Math.floor(intRowSpan / 2);
            const remainingRowSpan = intRowSpan - newRowSpan;
            cell.setAttribute('rowspan', newRowSpan);
            const newCell = document.createElement('td');
            newCell.setAttribute('rowspan', remainingRowSpan);
            newCell.style = "border: 1px solid black";
            newCell.innerHTML = "&nbsp;";
            let nextRow = row;
            for (let i = 0; i < newRowSpan; i++) {
                nextRow = nextRow.nextElementSibling;
                if (!nextRow) {
                    nextRow = document.createElement('tr');
                    row.parentElement.appendChild(nextRow);
                }
                nextRow.insertBefore(newCell.cloneNode(true), nextRow.children[colIndex]);
            }
        } else {
            const newCell = document.createElement('td');
            newCell.innerHTML = "&nbsp;";
            newCell.style = "border: 1px solid black";
            row.insertBefore(newCell, cell.nextSibling);
            const rows = Array.from(selectedTable.rows);
            rows.forEach((currentRow) => {
                if (currentRow !== row) {
                    const targetCell = currentRow.cells[colIndex];
                    if (targetCell) {
                        const currentRowSpan = parseInt(targetCell.getAttribute('rowspan')) || 1;
                        targetCell.setAttribute('rowspan', currentRowSpan + 1);
                    }
                }
            });
        }
        cell.classList.remove('selectedcell');
    });
    document.getElementById('tablosagtusmenu').style.display = 'none';
}