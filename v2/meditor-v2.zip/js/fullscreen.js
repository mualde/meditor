function AddfullscreenBtn() {
    const fullscreenContainer = document.createElement('div');
    fullscreenContainer.id = 'tamekran-container';
    fullscreenContainer.innerHTML = `
        <button type="button" id="fullscreenBtn" title="Tam Ekran Yap" onclick="toggleFullscreen();">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px" fill="#c7b304"><path d="M120-120v-240h80v104l124-124 56 56-124 124h104v80H120Zm480 0v-80h104L580-324l56-56 124 124v-104h80v240H600ZM324-580 200-704v104h-80v-240h240v80H256l124 124-56 56Zm312 0-56-56 124-124H600v-80h240v240h-80v-104L636-580ZM480-400q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Z"/></svg>
            </span>
        </button>`;
    if (toolbar) {toolbar.appendChild(fullscreenContainer);}
};

function toggleFullscreen() {
	var currentBackground = document.body.style.backgroundColor || bodyBgColor || 'White';
	if (!editor.classList.contains('tamekraneditor')) {
		
		toolbar.style.zIndex = '999';
		toolbar.style.width = '100%';
		toolbar.style.position = 'fixed';
		toolbar.style.top = '0';
		toolbar.style.left = '0';
		toolbar.style.margin = '0';
		toolbar.style.boxSizing = 'border-box';		
		
		editor.style.zIndex = '99';
		editor.style.width = '100%';
		editor.style.height = `calc(100vh - ${parseInt(window.getComputedStyle(toolbar).height, 10)}px)`;
		editor.style.position = 'fixed';
		editor.style.top = window.getComputedStyle(toolbar).height;
		editor.style.left = '0';
		editor.style.margin = '0';
		editor.style.boxSizing = 'border-box';

		sourceCode = document.getElementById("sourceCode");
		sourceCode.style.zIndex = '99';
		sourceCode.style.width = '100%';
		sourceCode.style.height = `calc(100vh - ${parseInt(window.getComputedStyle(toolbar).height, 10)}px)`;
		sourceCode.style.position = 'fixed';
		sourceCode.style.top = window.getComputedStyle(toolbar).height;
		sourceCode.style.left = '0';
		sourceCode.style.margin = '0';
		sourceCode.style.boxSizing = 'border-box';

		document.body.style.overflow = 'hidden';

		editor.classList.add('tamekraneditor');
		toolbar.classList.add('tamekrantoolbar');
		sourceCode.classList.add('tamekrankaynak');
		editor.style.backgroundColor = currentBackground;

	} else {
		editor.style = '';
		editor.style.backgroundColor = currentBackground;
		toolbar.style = '';
		sourceCode.style = '';

		editor.classList.remove('tamekraneditor');
		toolbar.classList.remove('tamekrantoolbar');
		sourceCode.classList.remove('tamekrankaynak');
		sourceCode.style.display = 'none';
		
		document.body.style.overflow = '';
	}
	moveCursorToStart(editor);
	
}