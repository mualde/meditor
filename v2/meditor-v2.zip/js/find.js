// Add the search button to toolbar
function AddFindBtn() {
    const findContainer = document.createElement('div');
    findContainer.id = 'find-container';
    findContainer.innerHTML = `
        <button type="button" id="findBtn" title="Bul" onclick="openFindMenu();">
            <span class="me-buton">
                <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="m590-160 80 80H240q-33 0-56.5-23.5T160-160v-640q0-33 23.5-56.5T240-880h360l200 240v480q0 20-8.5 36.5T768-96L560-302q-17 11-37 16.5t-43 5.5q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 23-5.5 43T618-360l102 104v-356L562-800H240v640h350ZM480-360q33 0 56.5-23.5T560-440q0-33-23.5-56.5T480-520q-33 0-56.5 23.5T400-440q0 33 23.5 56.5T480-360Zm0-80Zm0 0Z"/></svg>
            </span>
        </button>
        <div id="find-menu" style="display:none">
            <div class="ace_search right" style="">
                <span action="hide" class="ace_searchbtn_close" onclick="openFindMenu()">×</span>
                <div class="ace_search_form" style="display: flex;">
                    <input class="ace_search_field" placeholder="Şunu Ara" spellcheck="false">
                    <button action="findPrev" type="button" class="ace_searchbtn prev">Önceki</button>
                    <button action="findNext" type="button" class="ace_searchbtn next">Sonraki</button>
                </div>
                <div class="ace_replace_form" style="display: flex; margin-top: 8px;">
                    <input class="ace_search_field" placeholder="Şununla Değiştir" spellcheck="false">
                    <button type="button" action="replaceAndFindNext" class="ace_searchbtn">Değiştir</button>
                    <button type="button" action="replaceAll" class="ace_searchbtn">Hepsi</button>
                </div>
                <div class="ace_search_options">
                    <span class="ace_search_counter">0 of 0</span>
                    <span action="toggleCaseSensitive" class="ace_button" title="Case Sensitive Search">Aa</span>
                    <span action="toggleWholeWords" class="ace_button" title="Whole Word Search">\b</span>
                </div>
            </div>
        </div>
    `;

    if (toolbar) {
        toolbar.appendChild(findContainer);
        initSearchFunctions();
    }
};

// Toggle search menu visibility
function openFindMenu() {
    const menu = document.getElementById('find-menu');
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
        clearHighlights();
    } else {
        menu.style.display = 'block';
        const searchField = document.querySelector('#find-menu .ace_search_field');
        if (searchField) {
            searchField.focus();
            searchField.select();
        }
    }
}

// Initialize search functionality
function initSearchFunctions() {
    const editor = document.getElementById('editor');
    const searchField = document.querySelector('#find-menu .ace_search_field');
    const prevBtn = document.querySelector('#find-menu button[action="findPrev"]');
    const nextBtn = document.querySelector('#find-menu button[action="findNext"]');
    const replaceField = document.querySelector('#find-menu .ace_replace_form .ace_search_field');
    const replaceBtn = document.querySelector('#find-menu button[action="replaceAndFindNext"]');
    const replaceAllBtn = document.querySelector('#find-menu button[action="replaceAll"]');
    const searchCounter = document.querySelector('#find-menu .ace_search_counter');
    const caseSensitiveBtn = document.querySelector('[action="toggleCaseSensitive"]');
    const wholeWordBtn = document.querySelector('[action="toggleWholeWords"]');
    
    let currentMatchIndex = -1;
    let matches = [];
    let lastSearchText = '';

    // Clear all highlights
    function clearHighlights() {
        const highlights = editor.querySelectorAll('.search-highlight');
        highlights.forEach(highlight => {
            const parent = highlight.parentNode;
            parent.replaceChild(document.createTextNode(highlight.textContent), highlight);
            parent.normalize();
        });
        matches = [];
        currentMatchIndex = -1;
        updateCounter();
    }

    // Find all matches and highlight them
    function findAndHighlight(searchText) {
        clearHighlights();
        
        if (!searchText) return false;
        
        const isCaseSensitive = caseSensitiveBtn.classList.contains('active');
        const isWholeWord = wholeWordBtn.classList.contains('active');
        
        const regexFlags = isCaseSensitive ? 'g' : 'gi';
        let regexPattern = searchText;
        
        if (isWholeWord) {
            regexPattern = `\\b${escapeRegExp(searchText)}\\b`;
        } else {
            regexPattern = escapeRegExp(searchText);
        }
        
        try {
            const regex = new RegExp(regexPattern, regexFlags);
            const textNodes = getTextNodes(editor);
            
            textNodes.forEach(node => {
                const text = node.nodeValue;
                let match;
                
                while ((match = regex.exec(text)) !== null) {
                    const range = document.createRange();
                    range.setStart(node, match.index);
                    range.setEnd(node, match.index + match[0].length);
                    
                    const span = document.createElement('span');
                    span.className = 'search-highlight';
                    span.textContent = match[0];
                    
                    range.deleteContents();
                    range.insertNode(span);
                    
                    matches.push({
                        element: span,
                        index: match.index,
                        length: match[0].length
                    });
                }
            });
            
            lastSearchText = searchText;
            updateCounter();
            return matches.length > 0;
        } catch (e) {
            console.error("Invalid regex:", e);
            searchCounter.textContent = "Invalid search pattern";
            return false;
        }
    }

    // Select a specific match
    function selectMatch(index) {
        if (matches.length === 0 || index < 0 || index >= matches.length) return false;
        
        // Clear current highlight
        matches.forEach(match => {
            match.element.classList.remove('current-highlight');
        });
        
        // Highlight the selected match
        const match = matches[index];
        match.element.classList.add('current-highlight');
        
        // Scroll to the match
        match.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        currentMatchIndex = index;
        updateCounter();
        return true;
    }

    // Find next match
    function findNext() {
        if (searchField.value !== lastSearchText) {
            if (!findAndHighlight(searchField.value)) return;
        }
        
        if (matches.length === 0) return;
        
        const nextIndex = (currentMatchIndex + 1) % matches.length;
        selectMatch(nextIndex);
    }

    // Find previous match
    function findPrev() {
        if (searchField.value !== lastSearchText) {
            if (!findAndHighlight(searchField.value)) return;
        }
        
        if (matches.length === 0) return;
        
        const prevIndex = (currentMatchIndex - 1 + matches.length) % matches.length;
        selectMatch(prevIndex);
    }

    // Replace current match and find next
    function replaceAndFindNext() {
        if (matches.length === 0 || currentMatchIndex === -1) {
            findNext();
            return;
        }
        
        const currentMatch = matches[currentMatchIndex];
        const replaceText = replaceField.value;
        
        // Replace the text
        currentMatch.element.replaceWith(document.createTextNode(replaceText));
        
        // Remove from matches array
        matches.splice(currentMatchIndex, 1);
        
        // Find matches again since content changed
        findAndHighlight(searchField.value);
        
        // Select the same position if possible
        if (matches.length > 0) {
            selectMatch(Math.min(currentMatchIndex, matches.length - 1));
        } else {
            currentMatchIndex = -1;
            updateCounter();
        }
    }

    // Replace all matches
    function replaceAll() {
        if (matches.length === 0) return;
        
        const replaceText = replaceField.value;
        
        // Replace from last to first to avoid index issues
        matches.sort((a, b) => b.index - a.index).forEach(match => {
            match.element.replaceWith(document.createTextNode(replaceText));
        });
        
        searchCounter.textContent = `${matches.length} replaced`;
        matches = [];
        currentMatchIndex = -1;
    }

    // Update the match counter
    function updateCounter() {
        if (matches.length === 0) {
            searchCounter.textContent = lastSearchText ? "0 of 0" : "";
        } else {
            searchCounter.textContent = `${currentMatchIndex + 1} of ${matches.length}`;
        }
    }

    // Helper function to get all text nodes
    function getTextNodes(node) {
        const textNodes = [];
        const walker = document.createTreeWalker(
            node,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );
        
        while (walker.nextNode()) {
            textNodes.push(walker.currentNode);
        }
        
        return textNodes;
    }

    // Helper function to escape regex special characters
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // Event listeners
    searchField.addEventListener('input', () => {
        findAndHighlight(searchField.value);
        if (matches.length > 0) {
            selectMatch(0);
        }
    });

    searchField.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.shiftKey ? findPrev() : findNext();
        }
    });

    prevBtn.addEventListener('click', findPrev);
    nextBtn.addEventListener('click', findNext);
    replaceBtn.addEventListener('click', replaceAndFindNext);
    replaceAllBtn.addEventListener('click', replaceAll);

    caseSensitiveBtn.addEventListener('click', () => {
        caseSensitiveBtn.classList.toggle('active');
        if (searchField.value) {
            findAndHighlight(searchField.value);
        }
    });

    wholeWordBtn.addEventListener('click', () => {
        wholeWordBtn.classList.toggle('active');
        if (searchField.value) {
            findAndHighlight(searchField.value);
        }
    });
}