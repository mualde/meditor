function AddLinkBtn() {
    const linkContainer = document.createElement('div');
    linkContainer.id = 'link-container';
    linkContainer.innerHTML = `
    <button type="button" id="linkBtn" title="Link Ekle" onclick="openLinkModal()">
        <span class="me-buton">
            <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M680-160v-120H560v-80h120v-120h80v120h120v80H760v120h-80ZM440-280H280q-83 0-141.5-58.5T80-480q0-83 58.5-141.5T280-680h160v80H280q-50 0-85 35t-35 85q0 50 35 85t85 35h160v80ZM320-440v-80h320v80H320Zm560-40h-80q0-50-35-85t-85-35H520v-80h160q83 0 141.5 58.5T880-480Z"/></svg>
        </span>
    </button>
    <div id="linkModal" class="me-modal" style="display:none">
        <div class="me-modal-content">
            <div class="me-modal-header">
              <h5 class="me-modal-title">Bağlantı Ekle</h5>
            </div>
            <div class="me-modal-body">
              <div class="mb-3" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px;position: relative;">
                <span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Link Özellikleri </span>
                <input type="text" id="linkText" placeholder="Köprü" style="width: 100%; user-select: none;">
                <div style="display:flex;justify-content: space-between;">
                    <select id="linkProtocol" style="width:120px; user-select: none;">
                      <option value="https://">https://</option>
                      <option value="#">Bayrak #</option>
                      <option value="javascript:">Javascript</option>
                      <option value="">Protokol Yok</option>
                    </select>
                    <input type="text" id="linkURL" placeholder="mualde.com" style="width: calc(100% - 125px); user-select: none;">
                </div>
                <div style="display:flex;justify-content: space-between;">
                    <select id="linkTarget" style="width:120px; user-select: none;">
                      <option value="_blank">Yeni Sayfa _blank</option>
                      <option value="_self">Aynı Sayfa _self</option>
                    </select>
                    <input type="text" id="linkTitle" placeholder="Link Açıklaması" style="width: calc(100% - 125px); user-select: none;">
                </div>
              </div>
            </div>
            <div class="me-modal-footer">
              <button type="button" onclick="InsertLink();">Uygula</button>
              <button type="button" onclick="closeModal();">İptal Et</button>
            </div>
        </div>
    </div>
    <div id="editLinkModal" class="me-modal" style="display:none">
        <div class="me-modal-content">
            <div class="me-modal-header">
              <h5 class="me-modal-title">Bağlantıyı Güncelle</h5>
            </div>
            <div class="me-modal-body">
              <div class="mb-3" style="border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
              <span style="position: absolute; top: -19px; left: 10px; padding:5px;background-color:#2e2e2e;color:white;border-radius:5px;font-size:10pt"> Link Özellikleri </span>
                <input type="text" id="editLinkText" placeholder="Köprü" style="width:100%; user-select: none;">
                <input type="text" id="editLinkURL" placeholder="https://mualde.com" style="width:100%; user-select: none;">
                <div style="display:flex;justify-content: space-between;">
                    <select id="editLinkTarget" style="width:120px; user-select: none;">
                      <option value="_blank">Yeni Sayfa _blank</option>
                      <option value="_self">Aynı Sayfa _self</option>
                    </select>
                    <input type="text" id="editLinkTitle" placeholder="Link Açıklaması" style="width: calc(100% - 125px); user-select: none;">
                </div>
              </div>
            </div>
            <div class="me-modal-footer">
              <button type="button" onclick="UpdateLink();">Güncelle</button>
              <button type="button" onclick="kaldirLink();">Linki Kaldır</button>
              <button type="button" onclick="closeModal()">İptal Et</button>
            </div>
          </div>
        </div>
    </div>`;

    if (toolbar) {toolbar.appendChild(linkContainer);}
	var linkBtnCon = document.getElementById('link-container');
	var linkBtn = document.getElementById('linkBtn');
};

function openLinkModal(event) {
  const selection = window.getSelection();
  const range = selection.getRangeAt(0);
  const linkText = document.getElementById("linkText");
  const linkURL = document.getElementById("linkURL");
  if (range) {
    const selectedText = range.toString();
    const wordRange = getWordAtRange(range);
    const oge = range.startContainer.parentNode;
    if (oge.tagName === "A") {openEditModal(oge);return;}

    if (selectedText) {
      linkText.value = selectedText;
    } else if (wordRange) {
      linkText.value = wordRange.toString();
    } else {
      linkText.value = "Köprü";
    }
  }
  document.getElementById("linkModal").style.display = "flex";
  linkURL.focus();
}

function InsertLink(){
  const linkText = document.getElementById("linkText").value || "Köprü";
  const linkURL = document.getElementById("linkProtocol").value+document.getElementById("linkURL").value || "https://mualde.com";
  const linkTarget = document.getElementById("linkTarget").value;
  const linkTitle = document.getElementById("linkTitle").value || 'Açıklama: '+linkText;
  const range = savedSelection;
  const anchorTag = document.createElement("a");
  anchorTag.href = linkURL;
  anchorTag.target = linkTarget;
  anchorTag.textContent = linkText;
  anchorTag.title = linkTitle;

  if (range) {
    const selectedText = range.toString();
    const wordRange = getWordAtRange(range);

    if (selectedText) {
      range.deleteContents();
      range.insertNode(anchorTag);
    } else if (wordRange) {
      const wordText = wordRange.toString();
      wordRange.deleteContents();
      wordRange.insertNode(anchorTag);
    } else {
      range.insertNode(anchorTag);
    }
    window.getSelection().removeAllRanges();
  }
  closeModal();
  resetModal();
};

function getWordAtRange(range) {
  const node = range.startContainer;
  if (node.nodeType === Node.TEXT_NODE) {
    const text = node.textContent;
    const offset = range.startOffset;
    const before = text.slice(0, offset).split(/\s+/).pop();
    const after = text.slice(offset).split(/\s+/)[0];
    const wordStart = offset - (before ? before.length : 0);
    const wordEnd = offset + (after ? after.length : 0);
    if (wordStart >= 0 && wordEnd <= text.length) {
      const wordRange = document.createRange();
      wordRange.setStart(node, wordStart);
      wordRange.setEnd(node, wordEnd);
      return wordRange;
    }
  }
  return null;
}

let currentEditingLink = null;

function openEditModal(linkElement) {
    currentEditingLink = linkElement;
    document.getElementById("editLinkText").value = linkElement.textContent;
    document.getElementById("editLinkURL").value = linkElement.getAttribute("href");
    document.getElementById("editLinkTarget").value = linkElement.target;
    document.getElementById("editLinkTitle").value = linkElement.title;
    document.getElementById("editLinkModal").style.display = "flex";
}

editor.addEventListener("contextmenu", (event) => {
    if (event.ctrlKey) {
        const target = event.target;
        if (target.tagName === "A") {
            event.preventDefault();
            openEditModal(target);
        }
    }
});


function UpdateLink(){
    if (currentEditingLink) {
        const newText = document.getElementById("editLinkText").value || "Köprü";
        const newURL = document.getElementById("editLinkURL").value || "https://mualde.com";
        const newTarget = document.getElementById("editLinkTarget").value;
        const newTitle = document.getElementById("editLinkTitle").value || 'Açıklama: '+newText;
        currentEditingLink.textContent = newText;
        currentEditingLink.href = newURL;
        currentEditingLink.target = newTarget;
        currentEditingLink.title = newTitle;
        closeEditModal();
        resetModal();
    }
}

function closeEditModal() {
    currentEditingLink = null;
    document.getElementById("editLinkModal").style.display = "none";
}

function removeLink(linkElement) {
    if (linkElement) {
        if (linkElement.textContent !== "Köprü") {
            const textNode = document.createTextNode(linkElement.textContent);
            linkElement.parentNode.replaceChild(textNode, linkElement);
        } else {
            linkElement.remove();
        }
    }
}

function kaldirLink() {
    if (currentEditingLink) {
        removeLink(currentEditingLink);
        closeEditModal();
        resetModal();

    }
}

function resetModal(){
  document.getElementById("linkText").value = '';
  document.getElementById("linkProtocol").value = 'https://';
  document.getElementById("linkURL").value = '';
  document.getElementById("linkTarget").value = '_blank';
  document.getElementById("linkTitle").value = '';
  document.getElementById("editLinkText").value = '';
  document.getElementById("editLinkURL").value = '';
  document.getElementById("editLinkTarget").value = '_blank';
  document.getElementById("editLinkTitle").value = '';
}