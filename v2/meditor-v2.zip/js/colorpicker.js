function AddColorBtn() {
    const colorContainer = document.createElement('div');
    colorContainer.id = 'color-container';
    colorContainer.innerHTML = `
		<button type="button" id="colorBtn" title="Renk Ekle" onclick="openColorMenu();">
			<span class="me-buton">
			    <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 32.5-156t88-127Q256-817 330-848.5T488-880q80 0 151 27.5t124.5 76q53.5 48.5 85 115T880-518q0 115-70 176.5T640-280h-74q-9 0-12.5 5t-3.5 11q0 12 15 34.5t15 51.5q0 50-27.5 74T480-80Zm0-400Zm-220 40q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm120-160q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm200 0q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm120 160q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17ZM480-160q9 0 14.5-5t5.5-13q0-14-15-33t-15-57q0-42 29-67t71-25h70q66 0 113-38.5T800-518q0-121-92.5-201.5T488-800q-136 0-232 93t-96 227q0 133 93.5 226.5T480-160Z"/></svg>
			</span>
		</button>
		<div id="font-color-menu" style="display:none">
			<div class="color-picker-item">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M167-120q-21 5-36.5-10.5T120-167l40-191 198 198-191 40Zm191-40L160-358l458-458q23-23 57-23t57 23l84 84q23 23 23 57t-23 57L358-160Zm317-600L261-346l85 85 414-414-85-85Z"/></svg>
				<input title="Metin Rengi" type="color" id="textColor" value="${rgbToHex(negColor(bodyBgColor))}" list style="width:50px" onchange="applyFontColor(event)">
                <button type="button" style="width:30px;padding: 5px;" title="Metin Rengini Temizle" onclick="applyFontColor('temizle')">
                    <span class="me-buton">
                        <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M800-436q0 36-8 69t-22 63l-62-60q6-17 9-34.5t3-37.5q0-47-17.5-89T650-600L480-768l-88 86-56-56 144-142 226 222q44 42 69 99.5T800-436Zm-8 380L668-180q-41 29-88 44.5T480-120q-133 0-226.5-92.5T160-436q0-51 16-98t48-90L56-792l56-56 736 736-56 56ZM480-200q36 0 68.5-10t61.5-28L280-566q-21 32-30.5 64t-9.5 66q0 98 70 167t170 69Zm-37-204Zm110-116Z"/></svg>
                    </span>
                </button>
			</div>
			<div class="color-picker-item">
				<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M600-40H440q-17 0-28.5-11.5T400-80v-240q0-17 11.5-28.5T440-360h40v-120H160q-33 0-56.5-23.5T80-560v-160q0-33 23.5-56.5T160-800h80v-40q0-17 11.5-28.5T280-880h480q17 0 28.5 11.5T800-840v160q0 17-11.5 28.5T760-640H280q-17 0-28.5-11.5T240-680v-40h-80v160h320q33 0 56.5 23.5T560-480v120h40q17 0 28.5 11.5T640-320v240q0 17-11.5 28.5T600-40Zm-120-80h80v-160h-80v160ZM320-720h400v-80H320v80Zm160 600h80-80ZM320-720v-80 80Z"/></svg>
				<input title="Arka Plan Rengi" type="color" id="bgColor" value="${rgbToHex(bodyBgColor)}" list style="width:50px" onchange="applyFontBgColor(event)">
				<button type="button" style="width:30px;padding: 5px;" title="Arkaplan Rengini Temizle" onclick="applyFontBgColor('temizle')">
                    <span class="me-buton">
                        <svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M800-436q0 36-8 69t-22 63l-62-60q6-17 9-34.5t3-37.5q0-47-17.5-89T650-600L480-768l-88 86-56-56 144-142 226 222q44 42 69 99.5T800-436Zm-8 380L668-180q-41 29-88 44.5T480-120q-133 0-226.5-92.5T160-436q0-51 16-98t48-90L56-792l56-56 736 736-56 56ZM480-200q36 0 68.5-10t61.5-28L280-566q-21 32-30.5 64t-9.5 66q0 98 70 167t170 69Zm-37-204Zm110-116Z"/></svg>
                    </span>
                </button>
			</div>
		</div>
    `;

    if (toolbar) {toolbar.appendChild(colorContainer);}
};

editor.addEventListener('click', function(event){
    if(document.getElementById('font-color-menu').style.display !== 'none'){
        document.getElementById('textColor').value = rgbToHex(event.target.style.color) || rgbToHex(negColor(bodyBgColor));
        document.getElementById('bgColor').value = rgbToHex(event.target.style.backgroundColor) || rgbToHex(bodyBgColor);
        console.log(rgbToHex(bodyBgColor));
    }
});

function openColorMenu() {document.getElementById('font-color-menu').style.display = (document.getElementById('font-color-menu').style.display === 'none' || document.getElementById('font-color-menu').style.display === '') ? 'block' : 'none';};

function applyFontColor(event) {
    var textColor = document.getElementById("textColor").value;
    const selection = window.getSelection();
    if(event === 'temizle'){
        textColor = '';
    }
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const commonAncestor = range.commonAncestorContainer;
        if (editor && editor.contains(commonAncestor)) {
            const selectedText = selection.toString();
            if (selectedText) {
                const selectedNode = range.startContainer;
                const parentElement = selectedNode.parentElement;
                const currentStyle = window.getComputedStyle(parentElement);
                if (range.startOffset > 0 || (!currentStyle.color && !currentStyle.backgroundColor)) {
                    const newSpan = document.createElement("span");
                    newSpan.style.color = textColor;
                    newSpan.textContent = selectedText;
                    range.deleteContents();
                    range.insertNode(newSpan);
                    moveCursorToEnd(newSpan);
                } else {
                    parentElement.style.color = textColor;
                    moveCursorToEnd(parentElement);
                }
            } else {
                let selectedElement = range.commonAncestorContainer;
                if (selectedElement.nodeType === Node.TEXT_NODE) {
                    selectedElement = selectedElement.parentElement;
                }
                selectedElement.style.color = textColor;
                moveCursorToEnd(selectedElement);
            }
        }
        document.getElementById('font-color-menu').style.display = 'none';
    }
}

function applyFontBgColor(event) {
    var bgColor = document.getElementById("bgColor").value;
    const selection = window.getSelection();
    if(event === 'temizle'){
        bgColor = '';
    }
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const commonAncestor = range.commonAncestorContainer;
        if (editor && editor.contains(commonAncestor)) {
            const selectedText = selection.toString();
            if (selectedText) {
                const selectedNode = range.startContainer;
                const parentElement = selectedNode.parentElement;
                const currentStyle = window.getComputedStyle(parentElement);
                if (range.startOffset > 0 || (!currentStyle.color && !currentStyle.backgroundColor)) {
                    const newSpan = document.createElement("span");
                    newSpan.style.backgroundColor = bgColor;
                    newSpan.textContent = selectedText;
                    range.deleteContents();
                    range.insertNode(newSpan);
                    moveCursorToEnd(newSpan);
                } else {
                    parentElement.style.backgroundColor = bgColor;
                    moveCursorToEnd(parentElement);
                }
            } else {
                let selectedElement = range.commonAncestorContainer;
                if (selectedElement.nodeType === Node.TEXT_NODE) {
                    selectedElement = selectedElement.parentElement;
                }
                selectedElement.style.backgroundColor = bgColor;
                moveCursorToEnd(selectedElement);
            }
        }
        document.getElementById('font-color-menu').style.display = 'none';
    }
}