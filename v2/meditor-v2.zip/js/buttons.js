// Stil uygulama butonları oluşturma fonksiyonu
function AddButtonsBtn() {
	const justifybuttons = [
        { id: 'justifyleftBtn', type: 'button', title: 'Sola Yasla', command: 'justifyLeft', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h720v80H120Zm0-160v-80h480v80H120Zm0-160v-80h720v80H120Zm0-160v-80h480v80H120Zm0-160v-80h720v80H120Z"/></svg>` },
        { id: 'justifycenterBtn', type: 'button', title: 'Ortala', command: 'justifyCenter', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h720v80H120Zm160-160v-80h400v80H280ZM120-440v-80h720v80H120Zm160-160v-80h400v80H280ZM120-760v-80h720v80H120Z"/></svg>`},
        { id: 'justifyrightBtn', type: 'button', title: 'Sağa Yasla', command: 'justifyRight',  val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-760v-80h720v80H120Zm240 160v-80h480v80H360ZM120-440v-80h720v80H120Zm240 160v-80h480v80H360ZM120-120v-80h720v80H120Z"/></svg>`},
		{ id: 'justifyfullBtn', type: 'button', title: 'İki Tarafa Yasla', command: 'justifyFull', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h720v80H120Zm0-160v-80h720v80H120Zm0-160v-80h720v80H120Zm0-160v-80h720v80H120Zm0-160v-80h720v80H120Z"/></svg>` }
	];
	const stylebuttons = [		
		{ id: 'boldBtn', type: 'button', title: 'Kalın', command: 'bold', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M272-200v-560h221q65 0 120 40t55 111q0 51-23 78.5T602-491q25 11 55.5 41t30.5 90q0 89-65 124.5T501-200H272Zm121-112h104q48 0 58.5-24.5T566-372q0-11-10.5-35.5T494-432H393v120Zm0-228h93q33 0 48-17t15-38q0-24-17-39t-44-15h-95v109Z"/></svg>` },
		{ id: 'italicBtn', type: 'button', title: 'İtalik', command: 'italic', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-200v-100h160l120-360H320v-100h400v100H580L460-300h140v100H200Z"/></svg>` },
		{ id: 'underlineBtn', type: 'button', title: 'Altı Çizili', command: 'underline', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-120v-80h560v80H200Zm280-160q-101 0-157-63t-56-167v-330h103v336q0 56 28 91t82 35q54 0 82-35t28-91v-336h103v330q0 104-56 167t-157 63Z"/></svg>` },
		{ id: 'strikeBtn', type: 'button', title: 'Üstü Çizili', command: 'strikeThrough', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M486-160q-76 0-135-45t-85-123l88-38q14 48 48.5 79t85.5 31q42 0 76-20t34-64q0-18-7-33t-19-27h112q5 14 7.5 28.5T694-340q0 86-61.5 133T486-160ZM80-480v-80h800v80H80Zm402-326q66 0 115.5 32.5T674-674l-88 39q-9-29-33.5-52T484-710q-41 0-68 18.5T386-640h-96q2-69 54.5-117.5T482-806Z"/></svg>` },
		{ id: 'subscriptBtn', type: 'button', title: 'Alt Simge', command: 'subscript', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M760-160v-80q0-17 11.5-28.5T800-280h80v-40H760v-40h120q17 0 28.5 11.5T920-320v40q0 17-11.5 28.5T880-240h-80v40h120v40H760Zm-525-80 185-291-172-269h106l124 200h4l123-200h107L539-531l186 291H618L482-457h-4L342-240H235Z"/></svg>` },
		{ id: 'superscriptBtn', type: 'button', title: 'Üst Simge', command: 'superscript', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M760-600v-80q0-17 11.5-28.5T800-720h80v-40H760v-40h120q17 0 28.5 11.5T920-760v40q0 17-11.5 28.5T880-680h-80v40h120v40H760ZM235-160l185-291-172-269h106l124 200h4l123-200h107L539-451l186 291H618L482-377h-4L342-160H235Z"/></svg>` }
	];
	const dentbuttons = [		
		{ id: 'indentBtn', type: 'button', title: 'İçe Girinti', command: 'indent', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h720v80H120Zm320-160v-80h400v80H440Zm0-160v-80h400v80H440Zm0-160v-80h400v80H440ZM120-760v-80h720v80H120Zm0 440v-320l160 160-160 160Z"/></svg>` },
		{ id: 'outdentBtn', type: 'button', title: 'Dışa Girinti', command: 'outdent', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-120v-80h720v80H120Zm320-160v-80h400v80H440Zm0-160v-80h400v80H440Zm0-160v-80h400v80H440ZM120-760v-80h720v80H120Zm160 440L120-480l160-160v320Z"/></svg>` }
	];
	const listbuttons = [		
		{ id: 'bulletedlistBtn', type: 'button', title: 'Madde Listesi', command: 'insertUnorderedList', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M360-200v-80h480v80H360Zm0-240v-80h480v80H360Zm0-240v-80h480v80H360ZM200-160q-33 0-56.5-23.5T120-240q0-33 23.5-56.5T200-320q33 0 56.5 23.5T280-240q0 33-23.5 56.5T200-160Zm0-240q-33 0-56.5-23.5T120-480q0-33 23.5-56.5T200-560q33 0 56.5 23.5T280-480q0 33-23.5 56.5T200-400Zm0-240q-33 0-56.5-23.5T120-720q0-33 23.5-56.5T200-800q33 0 56.5 23.5T280-720q0 33-23.5 56.5T200-640Z"/></svg>` },
		{ id: 'numberedlistBtn', type: 'button', title: 'Numaralı Liste', command: 'insertOrderedList', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M120-80v-60h100v-30h-60v-60h60v-30H120v-60h120q17 0 28.5 11.5T280-280v40q0 17-11.5 28.5T240-200q17 0 28.5 11.5T280-160v40q0 17-11.5 28.5T240-80H120Zm0-280v-110q0-17 11.5-28.5T160-510h60v-30H120v-60h120q17 0 28.5 11.5T280-560v70q0 17-11.5 28.5T240-450h-60v30h100v60H120Zm60-280v-180h-60v-60h120v240h-60Zm180 440v-80h480v80H360Zm0-240v-80h480v80H360Zm0-240v-80h480v80H360Z"/></svg>` }
	];
	const horizontalbuttons = [		
		{ id: 'inserthorizontalruleBtn', type: 'button', title: 'Yatay Çizgi Ekle', command: 'insertHorizontalRule', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M160-440v-80h640v80H160Z"/></svg>` }
	];
	const clearbuttons = [		
		{ id: 'selectallBtn', type: 'button', title: 'Tümünü Seç', command: 'selectAll', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-280v-400h400v400H280Zm80-80h240v-240H360v240ZM200-200v80q-33 0-56.5-23.5T120-200h80Zm-80-80v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm80-160h-80q0-33 23.5-56.5T200-840v80Zm80 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80v80h-80Zm0-640v-80h80v80h-80Zm160 640v-80h80q0 33-23.5 56.5T760-120Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80h80v80h-80Zm0-160v-80q33 0 56.5 23.5T840-760h-80Z"/></svg>` },
		{ id: 'removeformatBtn', type: 'button', title: 'Tüm Stilleri Kaldır', command: 'removeFormat', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M791-55 602-244l-82 84H190l-85-85q-23-23-23.5-57t22.5-58l188-194L55-791l57-57 736 736-57 57ZM224-240h262l59-61-197-197-188 194 64 64Zm491-119-57-57 142-146-198-198-142 146-56-56 140-146q23-24 56.5-24t56.5 23l199 199q23 23 23 57t-23 57L715-359ZM559-515ZM447-400Z"/></svg>` },
		{ id: 'deleteBtn', type: 'button', title: 'Tüm Seçimi Sil', command: 'delete', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M440-520h80v-280q0-17-11.5-28.5T480-840q-17 0-28.5 11.5T440-800v280ZM200-360h560v-80H200v80Zm-58 240h98v-80q0-17 11.5-28.5T280-240q17 0 28.5 11.5T320-200v80h120v-80q0-17 11.5-28.5T480-240q17 0 28.5 11.5T520-200v80h120v-80q0-17 11.5-28.5T680-240q17 0 28.5 11.5T720-200v80h98l-40-160H182l-40 160Zm676 80H142q-39 0-63-31t-14-69l55-220v-80q0-33 23.5-56.5T200-520h160v-280q0-50 35-85t85-35q50 0 85 35t35 85v280h160q33 0 56.5 23.5T840-440v80l55 220q13 38-11.5 69T818-40Zm-58-400H200h560Zm-240-80h-80 80Z"/></svg>` }
	];
	const functionbuttons = [		
		{ id: 'cutBtn', type: 'button', title: 'Kes', command: 'cut', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M760-120 480-400l-94 94q8 15 11 32t3 34q0 66-47 113T240-80q-66 0-113-47T80-240q0-66 47-113t113-47q17 0 34 3t32 11l94-94-94-94q-15 8-32 11t-34 3q-66 0-113-47T80-720q0-66 47-113t113-47q66 0 113 47t47 113q0 17-3 34t-11 32l494 494v40H760ZM600-520l-80-80 240-240h120v40L600-520ZM240-640q33 0 56.5-23.5T320-720q0-33-23.5-56.5T240-800q-33 0-56.5 23.5T160-720q0 33 23.5 56.5T240-640Zm240 180q8 0 14-6t6-14q0-8-6-14t-14-6q-8 0-14 6t-6 14q0 8 6 14t14 6ZM240-160q33 0 56.5-23.5T320-240q0-33-23.5-56.5T240-320q-33 0-56.5 23.5T160-240q0 33 23.5 56.5T240-160Z"/></svg>` },
		{ id: 'copyBtn', type: 'button', title: 'Kopyala', command: 'copy', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M360-240q-33 0-56.5-23.5T280-320v-480q0-33 23.5-56.5T360-880h360q33 0 56.5 23.5T800-800v480q0 33-23.5 56.5T720-240H360Zm0-80h360v-480H360v480ZM200-80q-33 0-56.5-23.5T120-160v-560h80v560h440v80H200Zm160-240v-480 480Z"/></svg>` },
		{ id: 'pasteBtn', type: 'button', title: 'Yapıştır', onclick: pasteText, val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h167q11-35 43-57.5t70-22.5q40 0 71.5 22.5T594-840h166q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560h-80v120H280v-120h-80v560Zm280-560q17 0 28.5-11.5T520-800q0-17-11.5-28.5T480-840q-17 0-28.5 11.5T440-800q0 17 11.5 28.5T480-760Z"/></svg>` }
	];
	const dobuttons = [		
		{ id: 'undoBtn', type: 'button', title: 'Geri Al', command: 'undo', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M280-200v-80h284q63 0 109.5-40T720-420q0-60-46.5-100T564-560H312l104 104-56 56-200-200 200-200 56 56-104 104h252q97 0 166.5 63T800-420q0 94-69.5 157T564-200H280Z"/></svg>` },
		{ id: 'redoBtn', type: 'button', title: 'İleri Al', command: 'redo', val: `<svg height="18px" viewBox="0 -960 960 960" width="18px"><path d="M396-200q-97 0-166.5-63T160-420q0-94 69.5-157T396-640h252L544-744l56-56 200 200-200 200-56-56 104-104H396q-63 0-109.5 40T240-420q0 60 46.5 100T396-280h284v80H396Z"/></svg>` }
	];

    if (toolbar) {
        const justifyContainer = document.createElement('div');justifyContainer.id = 'justify-container';
        const styleContainer = document.createElement('div');styleContainer.id = 'style-container';
        const dentContainer = document.createElement('div');dentContainer.id = 'dent-container';
        const listContainer = document.createElement('div');listContainer.id = 'list-container';
        const horizontalContainer = document.createElement('div');horizontalContainer.id = 'horizontal-container';
        const clearContainer = document.createElement('div');clearContainer.id = 'clear-container';
        const functionContainer = document.createElement('div');functionContainer.id = 'function-container';
        const doContainer = document.createElement('div');doContainer.id = 'do-container';
        		
		//element.setAttribute('onclick', 'calistir()');

        // Justify Butonları
        justifybuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            justifyContainer.appendChild(button);
        });
        
        // Stil Butonları
        stylebuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            styleContainer.appendChild(button);
        });
        
        // Girinti Butonları
        dentbuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            dentContainer.appendChild(button);
        });
        
        // Liste Butonları
        listbuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            listContainer.appendChild(button);
        });
        
        // Yatay Çizgi Butonu
        horizontalbuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            horizontalContainer.appendChild(button);
        });
        
        // Temizleme Butonları
        clearbuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            if (btn.command === 'selectAll') {
                button.onclick = selectAllText;
            } else {
                button.onclick = () => applyStyle(btn.command);
            }
            clearContainer.appendChild(button);
        });
        
        // Fonksiyon Butonları
        functionbuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            if (btn.onclick) {
                button.onclick = btn.onclick;
            } else {
                button.onclick = () => applyStyle(btn.command);
            }
            functionContainer.appendChild(button);
        });
        
        // Geri Al/İleri Al Butonları
        dobuttons.forEach(btn => {
            const button = document.createElement('button');
            button.type = btn.type;
            button.id = btn.id;
            button.title = btn.title;
            button.innerHTML = `<span class="me-buton">${btn.val}</span>`;
            button.onclick = () => applyStyle(btn.command);
            doContainer.appendChild(button);
        });

        // Toolbar'a tüm container'ları ekle
        toolbar.appendChild(justifyContainer);    // Hizalama butonları
        toolbar.appendChild(styleContainer);     // Stil butonları (kalın, italik vb.)
        toolbar.appendChild(dentContainer);      // Girinti butonları
        toolbar.appendChild(listContainer);      // Liste butonları
        toolbar.appendChild(horizontalContainer); // Yatay çizgi butonu
        toolbar.appendChild(clearContainer);     // Temizleme butonları
        toolbar.appendChild(functionContainer);  // Fonksiyon butonları (kes/kopyala/yapıştır)
        toolbar.appendChild(doContainer);        // Geri al/ileri al butonları
    }
}

// Stil uygulama fonksiyonu
function applyStyle(command) {
	if(command === 'delete'){
		if(!confirm('Editörü Temizlemek istediğinizden Eminmisiniz')){
			return false;
		}
	};
		if(command === 'selectAll'){
        selectAllText();
        return false;
	};
    const selection = window.getSelection();
    if (!selection.rangeCount) return; // Eğer seçim yoksa çık
    const range = selection.getRangeAt(0);
    const commonAncestor = range.commonAncestorContainer;
    const editor = document.getElementById('editor'); // Editör elementi
    if (editor.contains(commonAncestor)) {
        document.execCommand(command);
        moveCursorToEnd(commonAncestor);
    } else {
        console.log("Seçim yalnızca düzenleme alanında olmalıdır.");
    }
}

function selectAllText() {
    const editor = document.getElementById('editor');
    const range = document.createRange();
    range.selectNodeContents(editor);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
}

async function pasteText() {
try {
        // Pano verisini oku
        const text = await navigator.clipboard.readText();
        if (!text) {
            alert("Panoda bir içerik bulunamadı.");
            return;
        }

        // Seçimi al ve imleç konumunu belirle
        const selection = window.getSelection();
        const range = selection.getRangeAt(0); // Geçerli imleç veya seçimi al

        // Pano verisini imleç konumuna ekle
        range.deleteContents(); // Seçili metni sil (eğer varsa)
        const textNode = document.createTextNode(text);
        range.insertNode(textNode); // Pano verisini ekle

        // İmleci eklenen metnin sonuna taşı
        range.setStartAfter(textNode);
        range.setEndAfter(textNode);
        selection.removeAllRanges();
        selection.addRange(range);

    } catch (err) {
        console.error('Yapıştırma işlemi başarısız oldu:', err);
    }
}

function removeFormatAll() {
    const editor = document.getElementById("editor");
    if (editor) {
        // Tüm span, strong, em, b, i, u, font gibi etiketleri kaldır
        const formattedElements = editor.querySelectorAll("span, strong, em, b, i, u, font");
        formattedElements.forEach(el => {
            const parent = el.parentNode;
            parent.replaceChild(document.createTextNode(el.textContent), el);
        });
        
        // Inline stilleri temizle
        editor.querySelectorAll("*").forEach(el => {
            el.removeAttribute("style");
            el.removeAttribute("class");
        });
    }
}